#include<stdio.h>
int main()
{
    double C,F;
    scanf("%lf",&C);
    F=1.8*C+32;
    printf("F = %lf\n",F);
    return 0;
}
