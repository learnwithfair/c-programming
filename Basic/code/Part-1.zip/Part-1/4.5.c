#include<stdio.h>
main()
{
    int n=1;
    int n<=20;
    for(i=1;i<=10;i++){
      printf("%d*%d=%d\n",n,i,n*i);
    }
}
