#include<stdio.h>
int main()
{
    int n;
    printf("please press any number=");
    scanf("%d",&n);
    if(n>=0){
        printf("the number is positive\n");
    }
    else{
        printf("the number is negative\n");
    }
    getch();
    return 0;
}
