#include<stdio.h>
int main()
{
    int n,a,row;
    scanf("%d",&n);
    for (row=1;row<=n;row++){
        printf("    %d\n",row);
    }
}
