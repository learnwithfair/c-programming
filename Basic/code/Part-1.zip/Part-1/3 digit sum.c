#include<stdio.h>
int main()
{
    int a,b,c,sum=0,n1,n2,n3;
    scanf("%d %d %d",&n1,&n2,&n3);
    for(a=2,b=5,c=8;a<=n1,b<=n2,c<=n3;a=a+3,b=b+3,c=c+3)
    {
        sum=sum+a*b*c;

        if(a==n1||b==n2||c==n3)
    {
        printf(" %d * %d * %d ",a,b,c);
    }
    else
        printf("%d * %d * %d  +",a,b,c);
    }

    printf(" = %d",sum);
}
