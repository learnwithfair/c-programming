#include<stdio.h>
int main()
{
    int ara[]={1,67,34,76,87,98,76,54,32,65,88,77};
    int low=0,high=12,num,mid;
    printf("Please enter the number : ");
    scanf("%d",&num);
    while (low<=high){
        mid=(low+high)/2;
        if (num==ara[mid]){
            break;
        }
        if (num<ara[mid]){
            high=mid-1;
        }
        else {
            low=mid+1;
        }
    }

    if (low<high){
        printf("%d the number is not found in the ara",num);
    }
    else{
        printf("%d the number is found. the number is %dth element in the ara",ara[mid],mid);
    }
}
