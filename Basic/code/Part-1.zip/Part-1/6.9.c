#include<stdio.h>
int main()
{
    int i,j;
    int total[]={5,7,8,9,7,6,3,4,2,1,2,3};
    int count[11];
    for(i=0;i<11;i++){
        count[i]=0;
    }
    for(i=0;i<12;i++){
        count[total[i]]++;
        for(j=0;j<=10;j++){
            printf("%d\n",count[j]);
        }
        printf("\n");
    }
}
