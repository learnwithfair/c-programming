#include<stdio.h>
int main()
{
    int a,b,R,x,gcd,lcm;
    scanf("%d %d",&a,&b);
    if(a==0)gcd = a;
    else if (b==0) gcd =b;
    else{
        while(b!=0){
            R=b;
            b=a%b;
            a=R;
        }
        gcd = a;
    }
    printf("GCD = %d\n",gcd);
    return 0;
}
