#include<stdio.h>
int main()
{
    int ara[5]= {10,20,30,40,50};
    printf("%d\n%d\n",ara[-1],ara[5]);
}
