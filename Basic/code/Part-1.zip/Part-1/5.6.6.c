#include<stdio.h>
int main()
{
    double C,F;
    scanf("%lf",&F);
    C=(F-32)/1.8;
    printf("C = %lf\n",C);
    return 0;
}
