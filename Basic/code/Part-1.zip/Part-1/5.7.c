#include<stdio.h>
int main()
{
    int a,b,X,GCD;
    scanf("%d %d",&a,&b);
    if (a<b){
        X=a;
    }
    else{
        X=b;
    }
    for(;X>=1;X--){
        if(a%X==0 && b%X==0){
            GCD = X;
            break;
        }
    }
    printf("GCD=%d\n",GCD);
    return 0;
}
