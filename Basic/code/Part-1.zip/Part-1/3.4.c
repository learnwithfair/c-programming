#include<stdio.h>
int main()
{
    int number = 12;
    if(number>10);
    printf("the number is greater than ten\n");
}
