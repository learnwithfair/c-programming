#include<stdio.h>
int main()
{
    char r[3][3]={"RVRT","TRE","POI"};
    printf("%s\n",r);
    getch();
}

