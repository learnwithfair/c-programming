#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    printf("%x\n",a);
    return 0;
}
