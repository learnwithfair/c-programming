#include<stdio.h>
int main()
{
    int ara[5]={10,20,30,40,50};
    printf("first = %d\n3nd = %d\n",ara [0],ara[2]);
    return 0;
}
