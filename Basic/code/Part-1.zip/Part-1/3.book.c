#include<stdio.h>
int main()
{
    int y=100,x=200;

    printf("s= %d\n",y++);//22
    printf("r= %d\n",++y);//22
      printf("s= %d\n",10 + ++y);//33
    printf("r= %d\n",10 + ++y);//33

    printf("r= %d\n",10 + --y);//44

    printf("s= %d\n",10 + ++y);//44
    printf("r= %d\n",10 + y++);//44

}
