#include<stdio.h>
int main()
{
   char ch;
   printf("enter the first letter of your name=");
   getch();
   printf("the first letter of your name=%s\n",ch);
   return 0;
}
