#include<stdio.h>
main()
{
    int n;
    printf("please press number=");
    scanf("%d",&n);
    if(n>='1'|| n<='10'){
        printf("yes\n");
    }
    else{
        printf("no\n");
    }
    getch();
}
