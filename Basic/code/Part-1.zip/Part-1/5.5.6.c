#include<stdio.h>
int main()
{
    int n,x;
    scanf("%d",&n);
    x=n*n;
    printf("%d\n",x);
    return 0;
}
