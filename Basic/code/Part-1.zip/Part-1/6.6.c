#include<stdio.h>
double add(double x,double y);
int main()
{
    double a=2.1,b=3.2,c;
    c=add(a,b);
    printf("%lf",c);
}
double add(double a,double b){
double sum=a+b;
return sum;
}
