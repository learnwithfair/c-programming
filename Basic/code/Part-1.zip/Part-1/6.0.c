#include<stdio.h>
int main()
{
    int st=80,nd=74,rd=97,total;
    total = st*25/100+nd*25/100+rd*50/100;
    printf("%d\n",total);
}
