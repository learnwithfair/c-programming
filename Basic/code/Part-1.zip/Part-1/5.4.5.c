#include<stdio.h>
int main()
{
    int n,x;
    scanf("%d",&n);
    x=(n*(n+1)/2);
    printf("%d\n",x);
    return 0;
}
