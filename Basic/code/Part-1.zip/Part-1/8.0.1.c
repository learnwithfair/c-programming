#include<stdio.h>
int main()
{
    char country[]={  };
    scanf("%s",&country);
    printf("%s\n",country);
    getch();
    return 0;

}
