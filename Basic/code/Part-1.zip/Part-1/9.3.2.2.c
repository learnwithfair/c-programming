#include<stdio.h>
int main()
{
    char ara [100];
    while (NULL !=getc (ara)){
        printf("%s\n",ara);
    }
    return 0;
}
