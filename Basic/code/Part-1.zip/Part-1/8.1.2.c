#include<stdio.h>
int main()
{
    int ara[]= {1,2,3,4,5,6,45,23,65,777,888,75,76,66,88,100};
    int low=0,high=15,mid,num;
    printf("please enter any number : ");
    scanf("%d",&num);
    for(low=0;low<=12;low++){
        mid=(low+high)/2;
        if (num==ara[mid]){
            break;
        }
        if (num<ara[mid]){
           high=mid-1;
        }
        else{
            low=mid+1;
        }
    }
    if(low>high){
        printf("%d is not in the arra\n",num);
    }
    else {
        printf("%d is found in the ara.this is %dth element of arra\n ",ara[mid],mid);
    }
    return 0;
   getch();
}

