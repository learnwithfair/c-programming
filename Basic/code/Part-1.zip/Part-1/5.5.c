#include<stdio.h>
int main()
{
    int n,i,sum;
    scanf("%d",&n);
    for(i=1,sum=0;n>=i;i++){
        sum= sum+i;
        printf("%d\n",sum);
    }
}
