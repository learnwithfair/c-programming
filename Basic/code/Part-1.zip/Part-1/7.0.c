#include<stdio.h>
int main()
{
    double a,b;
    a=2.5;
    b=2.5;
    printf("%lf",a+b);
    getch();
}
