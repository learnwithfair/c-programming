#include<stdio.h>
int main()
{
    double a,b;
    scanf("%lf %lf", &a, &b);
    double c,s;
    scanf("%lf",c);
    s= b*c;
    printf("NUMBER = %d\n",a);
    printf("SALARY = U$ %0.2lf",s);
    return 0;
}
