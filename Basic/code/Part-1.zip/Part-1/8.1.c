#include <stdio.h>
int main()
{
    int ara[]={1,2,3,4,5,6,45,23,65,75,76,88,100};
    int low=0,high=13,num,mid;
    printf("please enter any number :   ");
    scanf("%d",&num);
    while(low<=high){
        mid=(low+high)/2;
        if (num==ara[mid]){
            break;

        }
        if(num<ara[mid]){
            high=mid-1;
        }
        else {
            low=mid+1;
        }
    }
    if (low>high){
        printf("%d is not in the arra\n",num);
    }
    else {
        printf("%d is found in the arra.it is the %dth element of the arra\n",ara[mid],mid);

    }
    return 0;

}
