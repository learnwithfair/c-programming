#include<stdio.h>
int main()
{
    double c,f;
    scanf("%lf",&c);
    f=9*c/5+32;
    printf("%.2lf",f);
    return 0;
}
