#include<stdio.h>
int main()
{
    int n;
    printf("please press the any number=");
    scanf("%d",&n);
    int remainder=n%2;
    if(remainder==0){
        printf("the number is even\n");
    }
    else{
        printf("the number is add\n");
    }
    getch();
}
