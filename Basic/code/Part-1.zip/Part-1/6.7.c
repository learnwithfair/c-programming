#include<stdio.h>
int main()
{
    int ft[]={},
         s[]={},
         f[]={};
         printf("please Enter ft mark : ");
         scanf("%d%d%d%d%d%d%d%d%d%d",&ft,&ft,&ft,&ft,&ft,&ft,&ft,&ft,&ft,&ft);
         printf("please Enter s mark : ");
         scanf("%d%d%d%d%d%d%d%d%d%d",&s,&s,&s,&s,&s,&s,&s,&s,&s,&s);
         printf("please Enter f mark : ");
         scanf("%d%d%d%d%d%d%d%d%d%d",&f,&f,&f,&f,&f,&f,&f,&f,&f,&f);
         double total[10];
         int i,m,count;
         for(i=0;i<10;i++){
            total[i]=ft[i]/4.0+s[i]/4.0+f[i]/2.0;
        }
        for (i=1;i<=10;i++){
            printf("Roll No : %d\t Total : %.0lf\n",i,total[i-1]);
        }
        for (m=77;m<=100;m++){
            count=0;
            for(i=0;i<10;i++){
               if(total[i-1]==m){
                count++;
               }
            }
           printf("M : %d\t count : %d\n",m,count);
        }

}
