#include<stdio.h>
int main()
{
    char ch;
    scanf("%c",&ch);
    printf("My name is = %c\n",ch);
    getch();
}
