#include<stdio.h>
main()
{
    char ch;
    printf("please press the any key=");
    scanf("%c",&ch);
    if(ch>='a' && ch<='z'){
        printf("%c the key is lower case\n");
    }
    else{
        printf("%c the key is upper case\n ");
    }
    getch();

}
