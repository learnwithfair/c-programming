#include<stdio.h>
int main()
{
    int a;
    scanf("%x",&a);
    printf("%o\n",a);
}
