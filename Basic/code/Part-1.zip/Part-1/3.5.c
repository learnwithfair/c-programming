#include<stdio.h>
int main()
{
    int n;
    printf("please press any number=");
    scanf("%d",&n);
    if(n<30){
        printf("the number less than is 30.\n");
    }
    else if(n<50){
        printf("the number less than in 50.\n");
    }
    else{
        printf("the number getter than is 50\n");
    }
    getch();
}
