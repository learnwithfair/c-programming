#include<stdio.h>
double add(double x,double y);
int main()
{
    double a,b,c;
    a=7.5;
    b=3.4;
    c=add(a,b);
    printf("%lf\n",c);
}
    double add(double num1,double num2){
    double sum=num1+num2;
    return sum;
}
