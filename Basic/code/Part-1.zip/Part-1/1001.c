#include<stdio.h>
int main()
{
    int A,B;
    scanf("%d %d", &A,&B);
    printf("x = %d\n",A+B);
    return 0;
}
