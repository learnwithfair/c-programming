#include<stdio.h>
double add(double x,double y);
int main()
{
    double a=3.5,b=4.6,c;
    c=add(a,b);
    printf("%lf",c);
    getch();
}
    double add(double  num1, double num2){
    double sum=num1+num2;
    return sum;
}
