#include<stdio.h>
int main()
{
    char ara[]={  };
    scanf("%s",&ara);
    printf("%s\n",ara);
}
