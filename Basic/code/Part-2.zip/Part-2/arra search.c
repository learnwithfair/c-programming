#include<stdio.h>
int main()
{
    int ara[]={10,20,30,50,301,40,110,2,402};
    int pos=-1,i,n;
    printf("Enter the value for you want search : ");
    scanf("%d",&n);
    for(i=0;i<9;i++)
    {
        if(n==ara[i])
        {
            pos=i+1;
            break;
        }
    }
    if(pos==-1)
    {
        printf("Item is  not found");
    }
    else
    {
        printf("%d number is found at the %d possition\n",n,pos);
    }
}
