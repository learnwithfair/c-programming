#include<stdio.h>
int main()
{
    int fr,sr,finalr;
    double total;
    scanf("%d%d%d",&fr,&sr,&finalr);
    total= fr/4.0+sr/4.0+finalr/2.0;
    printf("%.01lf",total);
}
