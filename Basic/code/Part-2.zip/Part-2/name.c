#include<stdio.h>
int main()
{
    char name;
    scanf("%s",&name);
    printf("%s\n");
}
