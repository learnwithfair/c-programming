#include<stdio.h>
int main()
{
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    for (a=1;a<=3;a=a+1){
       for(b=1;b<=3&&b!=a;b=b+1){
       for(c=1;c<=3&&c!=b&&c!=a;c=c+1){
        printf("%d, %d, %d",a,b,c);
       }
       }
    }
}
