#include<stdio.h>
int main()
{
    int fibo,n,num1=-1,num2=1,i;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        fibo=num1+num2;
        num1=num2;
        num2=fibo;
        printf("%d ",fibo);
    }
}
