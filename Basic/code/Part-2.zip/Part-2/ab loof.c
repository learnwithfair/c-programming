#include<stdio.h>
int main()
{
    int a,b,sum=0,n1,n2;
    scanf("%d %d",&n1,&n2);
    for(a=1,b=3;a<=n1,b<=n2;a=a+2,b=b+2)
    {
        sum=sum+a*b;

        if(a==n1&&b==n2)
    {
        printf("%d*%d",a,b);
    }
    else
        printf("%d * %d +",a,b);
    }

    printf(" = %d",sum);
}
