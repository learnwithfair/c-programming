#include<stdio.h>
int main()
{
    int i,n;
    scanf("%d",&n);
    i=1;
    while(i<=n){
        printf("%d) Zinnatun Nesa Jyoti\n",i);
        i++;
    }
}
