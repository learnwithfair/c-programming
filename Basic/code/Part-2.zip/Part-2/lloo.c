#include<stdio.h>
int main()
{
    int i,n,sum=0;
    printf("Enter any number : ");
    scanf("%d",&n);
    for(i=1;i<=n;i=i+1)
    {
        sum=sum+i*i; //a=b
    }
    printf("Sum = %d\n",sum);
    return 0;

}
/*
i=1
0+1*1 sum=1
i=2
1+2*2 sum=5
i=3
5+3*3 sum=14


*/
