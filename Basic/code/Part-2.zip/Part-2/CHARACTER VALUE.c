#include<stdio.h>
int main()
{
    char a;
    printf("Enter any character : ");
    scanf("%c",&a);
    printf("The value is : %d\n",a);
    getch();
}
