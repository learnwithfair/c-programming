#include<stdio.h>
int main()
{
    int A[10][10],B[10][10],AA[10][10],BB[10][10];
    int i,j,n1,n2,n3,n4;
    printf("\nPlease Enter rows number for A matrix : ");
    scanf("%d",&n1);
    printf("\nPlease Enter cols number for A matrix : ");
    scanf("%d",&n2);
    printf("\nA matrix : \n\n");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("A[%d][%d] : ",i,j);
            scanf("%d",&A[i][j]);
        }
    }
    printf("\nThe matrix A : \n");
    printf("\n\n\t   A = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }



    printf("\nPlease Enter rows number for B matrix : ");
    scanf("%d",&n3);
    printf("\nPlease Enter cols number for B matrix : ");
    scanf("%d",&n4);
    printf("\nB matrix : \n\n");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("B[%d][%d] : ",i,j);
            scanf("%d",&B[i][j]);
        }
    }
    printf("\nThe matrix B : \n");
    printf("\n\n\t   B = ");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }

    printf("\nTherefor The matrix A & B are : \n");

    printf("\n\n\t   A = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }
    printf("\n\n\t   B = ");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }


    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            AA[j][i]=A[i][j];
        }
    }
    printf("\nThe Transpose matrix A : \n");
    printf("\n\n\t   A = ");
    for(i=0; i<n2; i++)
    {
        for(j=0; j<n1; j++)
        {
            printf("%d ",AA[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            BB[j][i]=B[i][j];
        }
    }


    printf("\nThe Transpose matrix B : \n");
    printf("\n\n\t   B = ");
    for(i=0; i<n4; i++)
    {
        for(j=0; j<n3; j++)
        {
            printf("%d ",BB[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }
    getch();

}
