#include<stdio.h>
int main()
{
    int x=6,y=4,sum;
    int *ptr;
    ptr=&x;
    int *ptr1;
    ptr1=&y;
    sum=*ptr + *ptr1;
    printf("%d",sum);
}
