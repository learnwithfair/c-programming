#include<stdio.h>

int main()
{
    struct person
{
    int age;
    float salary;
    char name[300];
};
    struct person person[300];
    int i;

    for(i=0;i<3;i++)
    {
        printf("\n\nInformation for person%d : \n",i+1);
        printf("Enter name for person%d : ",i+1);
        fflush(stdin);
        gets(person[i].name);
        printf("Enter age for person%d : ",i+1);
        scanf("%d",&person[i].age);
        printf("Enter salary for person%d : ",i+1);
        scanf("%f",&person[i].salary);
    }
    for(i=0;i<3;i++)
    {
        printf("\n\nInformation for person%d : \n",i+1);
        printf("the person%d age is %s \n",i+1,person[i].name);
        printf("the person%d age is %d \n",i+1,person[i].age);
        printf("the person%d age is %f \n",i+1,person[i].salary);

    }
    getch();
}
