#include<stdio.h>
struct person
{
    int age;
    float salary;
};
int main()
{
    struct person person1= {27,2546.26};
   struct person person2,person3;
    person2=person1;
    person3.age=25;
    person3.salary=2545.65;


    if (person2.age==person1.age&&person2.salary==person1.salary)
    {
        printf("The value of person1 equal person2");
    }
    else
    {
        printf("The value of person1 not equal person2");

    }
    getch();
}
