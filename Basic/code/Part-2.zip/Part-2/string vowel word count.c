#include<stdio.h>
int main()
{
    char str[300],ch;
    int i,vowel,consonant,digit,other,word;
    printf("Enter any number : ");
    gets(str);

    i=vowel=word=digit=consonant=other=0;
    while(ch=str[i]!='\0')
    {
        ch=str[i];
        if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||
                ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
        vowel++;
        else if (ch>='0'&&ch<='9')
            digit++;
        else if ((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z'))
            consonant++;
        else if  (ch==' ')
            word++;
        else
            other++;
        i++;
    }
    word++;
    printf("Vowel number = %d\n",vowel);
    printf("consonant number = %d\n",consonant);
    printf("digit number = %d\n",digit);
    printf("Word number = %d\n",word);
    printf("Other number = %d\n",other);
}
