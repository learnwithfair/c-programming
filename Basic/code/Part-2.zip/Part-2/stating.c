#include<stdio.h>
int main()
{
    char n[20];
    scanf("%s",n);
    printf("%s\n",n);
}
