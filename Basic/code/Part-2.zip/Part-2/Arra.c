#include<stdio.h>
int main()
{
    int num[100];
    int i,n,j,sum=0;
    double avg;
    printf("Please Enter number : ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&num[i]);
    }
    for(i=0;i<n;i++)
    {
        sum=sum+num[i];
        avg=sum/n;
    }
    printf("sum = %d \n",num[i]);
    printf("avg = %.2lf",avg);

}
