#include<stdio.h>
int main()
{
    int i,n,n1=-1,n2=1,fibo,sum=0;
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        fibo=n1+n2;
        n1=n2;
        n2=fibo;
        printf("%d ",fibo);
        sum=sum+fibo;

    }
    printf(" = %d",sum);

    getch();


}
