#include<stdio.h>
int main()
{
    int n,a,b;
    double num1,num2,value;
    printf("Choice from menu : \n");
    printf("1) Sum the value:\n");
    printf("2) Sub the value:\n");
    printf("3) multiple the value:\n");
    printf("4) Division the value:\n");
    printf("5) Modulus the value:\n");
    scanf("%d",&n);
    switch(n)
    {
        case 1:{
        printf("Please Enter two numbers :\n");
        scanf("%lf %lf",&num1,&num2);
        value= num1+num2;
        printf("Total Sum of the value is %.0lf+%.0lf= %.2lf\n",num1,num2,value);
        break;
        }
        case 2:{
        printf("Please Enter two numbers :\n");
        scanf("%lf %lf",&num1,&num2);
        value= num1-num2;
        printf("Total Sub of the value is %.0lf-%.0lf= %.2lf\n",num1,num2,value);
        break;
        }
        case 3:{
        printf("Please Enter two numbers :\n");
        scanf("%lf %lf",&num1,&num2);
        value= num1*num2;
        printf("Total Multiple of the value is %.0lf*%.0lf= %.2lf\n",num1,num2,value);
        break;
        }
        case 4:{
        printf("Please Enter two numbers :\n");
        scanf("%lf %lf",&num1,&num2);
        value=num1/num2;
        printf("Total Division of the value is %.0lf / %.0lf= %.2lf\n",num1,num2,value);
        break;
        }
        case 5:{
        printf("Please Enter two numbers :\n");
        scanf("%d %d",&a,&b);
        value=a%b;
        printf("Total Modulus of the value is %d %% %d= %.0lf\n",a,b,value);
        break;
        }
        default:
            printf("No Find your List\n");
    }
}
