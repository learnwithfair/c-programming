#include<stdio.h>
int main()
{

    printf("First line  :   Name\nSecond line   :   Door No,Street\nThird line :   City,pin code\n");
    getch ();
}
