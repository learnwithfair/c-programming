#include<stdio.h>
int main()
{
    int ara[100];
    int n,i,a;
    scanf("%d",&n);
    ara[0]=-1;
    ara[1]=1;
    for(i=2;i<=n+1;i++)
    {
        a=ara[i-2]+ara[i-1];
        ara[i-2]=ara[i-1];
        ara[i-1]=a;
    printf("%d ",a);
    }


}
