#include<stdio.h>
int main()
{
    printf("\t::::::::::::\n\t::        ::\n\t::        ::\n\t::::::::::::\n\t::   ::\n\t::    ::\n\t::     ::\n\t::      ::\n");
}
