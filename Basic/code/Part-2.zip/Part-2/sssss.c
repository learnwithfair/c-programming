#include<stdio.h>
int main()
{
    int i,n,mul;
    printf("Enter any number : ");
    scanf("%d",&n);
    for(i=1;i<=10;i=i+1)
    {
        mul=i*n;
        printf("%d * %d = %d\n",n,i,mul);
    }
    getch();

}
/*
i=1
5*1 mul=5
i=2
2*5 mul=10
i=3
3*5 mul=15

*/
