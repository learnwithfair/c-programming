#include<stdio.h>
int main ()
{
    int a=40,b=80,sum;
    sum=a+b;
    printf("%d+%d=%d",a,a,sum);
}
