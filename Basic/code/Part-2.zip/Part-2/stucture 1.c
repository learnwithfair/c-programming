#include<stdio.h>
struct person
{
    int age;
    float salary;
};
int main()
{
    //local

    struct person person1,person2;
    person1.age=27;
    person1.salary=27022.25;
    person2.age=25;
    person2.salary=25663.25;
    printf("The person1 age is %d\n",person1.age);
    printf("The person1 salary is %.2f\n",person1.salary);
    printf("\n\nThe person2 age is %d\n",person1.age);
    printf("The person2 salary is %.2f\n",person1.salary);
    getch();
}
