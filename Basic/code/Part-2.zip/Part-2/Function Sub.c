#include<stdio.h>
void sub(int a, int b)
{
    int s,result;
    result=a-b;
    printf("Total Sub is %d",result);
}

int main()
{
    int num1,num2;
    printf("Enter two number : ");
    scanf("%d %d",&num1,&num2);
    sub(num1,num2);
}
