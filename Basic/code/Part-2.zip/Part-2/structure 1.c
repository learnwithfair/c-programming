#include<stdio.h>
struct person
{
    int age;
    float salary;
};
int main()

{
    struct person person1,person2;
    person1.age=27;
    person1.salary=256240.25;
    printf("\n\nThe person1 age is %d\n",person1.age);
    printf("The person1 salary is %.2f",person1.salary);

     getch();
}
