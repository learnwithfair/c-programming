#include<stdio.h>
int main()
{
    char str1[300],tem[300];
    printf("Enter 1st string : ");
    gets(str1);
    char str2[300];
    printf("Enter 2nd string : ");
    gets(str2);
    printf("before swapping:\n");
    printf("1st string = %s\n",str1);
    printf("2nd string = %s\n",str2);
    strcpy(tem,str1);
    strcpy(str1,str2);
    strcpy(str2,tem);
    printf("after swapping:\n");
    printf("1st string = %s\n",str1);
    printf("2nd string = %s\n",str2);
    getch();
}
