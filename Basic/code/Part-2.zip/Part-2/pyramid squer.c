#include<stdio.h>
int main()
{
    int n, row,col;
    scanf("%d",&n);
    printf("\n");
    for(row=1;row<=n;row++)
    {
        for(col=1;col<=n;col++)
        {
            printf("%d ",row);
        }
        printf("\n");
    }
}

