#include<stdio.h>
int recorsion(int n)
{
    if(n==1)
        return 1;
    else
        return n*recorsion(n-1);
}
int main()

{
    int num,fact;
    printf("Enter any number : ");
    scanf("%d",&num);
    fact=recorsion(num);
    printf("Te Factorial number is %d",fact);
}
