#include<stdio.h>
int main()
{
    char str1[300];
    char str2[300];
    printf("Enter any string :");
    gets(str1);
    int i,j,count=0;
    i=0;
    while(str1[i]!='\0')
    {
        count++;
        i++;
    }
    printf("%d",count);
}
