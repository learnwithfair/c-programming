#include<stdio.h>
void squere(int a)
{
    int result=a*a;
    printf("Total result is %d",result);
    getch ();
}

int main()
{
    int num;
    printf("Enter any number : ");
    scanf("%d",&num);
    squere(num);
}

