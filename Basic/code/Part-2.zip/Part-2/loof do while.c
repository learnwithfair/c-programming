#include<stdio.h>
int main()
{
    int i,n;
    scanf("%d",&n);
    i=1;
    do{
        printf("%d) Zinnatun nesa Jyoti\n",i);
        i++;
    }
    while (i<=n);
}
