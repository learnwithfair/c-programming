#include<stdio.h>
int main()
{
    int x=4;
    int *ptr;
    ptr=&x;
    printf("x= %d\n",*ptr);
    int y=6;
    ptr=&y;
    printf("y= %d\n",*ptr);
    int p=7;
    ptr=&p;
    printf("p= %d\n",*ptr);
    int z=9;
    ptr=&z;
    printf("z= %d\n",*ptr);

}
