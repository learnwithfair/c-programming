#include<stdio.h>
int main()
{
    char str[]="Rahatul";
    int i,count=0;
    i=0;
    while(str[i]!='\0')
    {
        count=count+1;

        i++;

    }
    printf("%d",count);
    getch();
}
