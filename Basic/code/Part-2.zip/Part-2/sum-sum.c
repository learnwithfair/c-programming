#include<stdio.h>
int main()
{
    int n,s,i,s1=0,s2=0;
    scanf("%d",&n);
    for (i=2;i<=n;i=i+4){
            s1=s1+i;
    }
    for (i=4;i<=n;i=i+4){
            s2=s2+i;
    }
    s=s1-s2;
    printf("%d",s);

}
