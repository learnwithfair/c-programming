#include<stdio.h>
int main()
{
    int ara[100];
    int n,i,max,min;
    printf("How many number for maximum or minimum ");
    scanf("%d",&n);
    printf("Please Enter any three number : ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&ara[i]);
    }
    max=ara[0];
    for(i=1;i<n;i++)
    {
        if(max<ara[i])
            max=ara[i];

    }
    printf("maximum value is %d\n",max);

}
