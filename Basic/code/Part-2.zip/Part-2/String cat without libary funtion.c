#include<stdio.h>
int main()
{
    char str1[20],str2[20];
    int i,len;
    printf("Enter First string : ");
    gets(str1);
    printf("Enter Second string : ");
    gets(str2);
    len=strlen(str1);
    i=0;
    while(str1[i]!='\0')
    {
        str1[len+i]=str2[i];
        i++;
    }
    printf("%s\n",str1);
    getch();
}
