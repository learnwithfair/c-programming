#include<stdio.h>
int main()
{
    int n,i,sum=1;
    printf("Enter any number : ");
    scanf("%d",&n);
    for(i=1;i<=10;i++)
    {
        sum=n*i;//4*1=4 sum=4
       printf("%d * %d = %d\n",n,i,sum); //4*2= sum=8
    }

}
