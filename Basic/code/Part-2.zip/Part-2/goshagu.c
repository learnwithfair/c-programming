#include<stdio.h>
int main()
{
    int num1,num2,res,LCM;
    scanf("%d %d",&num1,&num2);
    while(num2!=0);
    res=num1%num2;
    num1=num2;
    num2=res;
    printf("%d\n",num1);
    LCM=(num1*num2)/res;
    printf("LCM= %d\n",LCM);


}
