#include<stdio.h>
int main()
{
    int i;
    float f;
    double b;
    char c;
    printf("size of int %d byte\n",sizeof(i));
    printf("size of float %d byte\n",sizeof(f));
    printf("size of double % dbyte\n",sizeof(b));
    printf("size of char %d byte\n",sizeof(c));
    getch();
}
