#include<stdio.h>
int main()
{
    int month,days,m,d;
    scanf("%d",&days);
    m= days/30;
    days=days%30;
    d= days;
    printf("month = %d\ndays = %d\n",m,d);
    return 0;
}
