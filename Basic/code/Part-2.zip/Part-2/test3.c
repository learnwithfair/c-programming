#include<stdio.h>
int main()
{
    int num1,num2,res,lcd,gcm,n1,n2;
    scanf("%d %d",&num1,&num2);
    n1=num1;
    n2=num2;
    while(n2!=0)
    {
        res=n1%n2;
        n1=n2;
        n2=res;
    }
    gcm=n1;
    printf("GCM=%d\n",gcm);
    lcd=(num1*num2)/gcm;
    printf("LCD=%d\n",lcd);
}

