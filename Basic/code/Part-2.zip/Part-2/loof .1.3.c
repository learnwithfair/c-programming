#include<stdio.h>
int main()
{
    double n,i,sum=0;
    scanf("%lf",&n);
    for(i=1;i<=n;i++)
    {
        sum=sum+(1/i);

    if(i==1)
    {
        printf("\n\t1 + ");
    }
    else if(i==n)
    {
        printf(" 1/%.0lf ",n);
    }
    else
    {
        printf(" 1/%.0lf +",i);
    }
    }
    printf(" = %.1lf\n",sum);

}
