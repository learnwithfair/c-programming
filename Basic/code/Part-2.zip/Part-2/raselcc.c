#include<stdio.h>
int main()
{
    char n;
    printf("enter name= ");
    scanf("%c",&n);
    printf("%s\n",n);
}
