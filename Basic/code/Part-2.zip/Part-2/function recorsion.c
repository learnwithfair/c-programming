#include<stdio.h>
int main()
{
    int num,fact;
    printf("Enter any number : ");
    scanf("%d",&num);
    fact=recorsion(num);
    printf("Facttorial value is %d",fact);
}
int recorsion(int a)
{
    if(a==1)
        return 1;
    else
        return a*recorsion(a-1);


}
