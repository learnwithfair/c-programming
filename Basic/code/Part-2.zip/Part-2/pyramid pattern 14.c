#include<stdio.h>
int main()
{
    int n,row,col;
    scanf("%d",&n);
    for(row=1;row<=n;row++)
    {
        for(col=1;col<=n-row;col++)
        {
            printf(" ");
        }
        for(col=1;col<=row;col++)
        {
            printf("%d",col);
        }
        for(col=row;col>=1;col--)
        {   if(col==1)
        {
            printf("");
        }
        else
            printf("%d",col);
        }
        printf("\n");
    }
}
