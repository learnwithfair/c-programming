#include<stdio.h>
int main()
{
    int ara[1000];
    int min,n,i;
    printf("How many number for Minimum value: ");
    scanf("%d",&n);
    printf("\nPlease Enter Numbers for Minimum value :");
    for(i=0;i<n;i++)
    {
        scanf("%d",&ara[i]);
    }
    min=ara[0];
    for(i=1;i<n;i++)
    {
        if(min>ara[i])
        min=ara[i];
    }
    printf("Minimum Value is %d",min);
}
