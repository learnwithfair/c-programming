#include<stdio.h>
#include<math.h>
int main()
{
    char n,x;
    scanf("%c",&n);
    x=tolower(n);
    printf("%c",x);
    return 0;
}
