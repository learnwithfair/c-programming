#include<stdio.h>
int main()
{
    int i,n;
    scanf("%d",&n);
    i=1;
    Rahat:
        printf("%d\n",i);
        i++;
        if(i<=n)
        goto Rahat;
        return 0;
}
