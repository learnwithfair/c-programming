#include<stdio.h>
int main()
{
    char str1[200],str2[200];
    int i,j,count=0;
    printf("Enter 1st sentence : ");
    gets(str1);
    printf("Enter 2st sentence : ");
    gets(str2);
    i=0;
    while(str1[i]!='\0')
    {
        count++;
        i++;
    }
    j=0;
    while(str1[j]!='\0')
    {
        str1[count+j]=str2[j];
        j++;
    }
    printf("%s",str1);
}
