#include<stdio.h>
int main()
{
    int a;//log, log10,sin,cos,exp,pow,abs,round,ceil,floor,trunc
    char b;
    float c;
    double d;
    printf("%d\n",sizeof(a));
    printf("%d\n",sizeof(b));
    printf("%d\n",sizeof(c));
    printf("%d\n",sizeof(d));
}
