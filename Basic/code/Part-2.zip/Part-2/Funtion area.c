#include<stdio.h>
void area(int a,int b)
{
   double result;
   result =.5*a*b;
   printf("Total Area is %.2lf",result);
}
int main()
{
    int base,hight;
    printf("Enter Hight : ");
    scanf("%d",&hight);
    printf("Enter Base : ");
    scanf("%d",&base);
    area(hight,base);
}
