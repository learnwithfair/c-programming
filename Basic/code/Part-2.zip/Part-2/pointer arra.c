#include<stdio.h>
int main()
{
    int i,a[]={5,4,89,35,24,23};
    int *p;

    for(i=0;i<6;i++)
    {
        p=&a[i];
        printf("%d\n",*p);
    }
}
