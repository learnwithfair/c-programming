#include<stdio.h>
int main()
{
    int num1=5,num2=10,temp;
    temp= num1;
    num1=num2;
    num2=temp;
    printf("num1= %d\nnum2= %d\n",num1,num2,temp);
    getch ();
}
