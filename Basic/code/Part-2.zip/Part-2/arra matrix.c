#include<stdio.h>
int main()
{
    int A[10][10],B[10][10];
    int i,j,n1,n2;
    printf("How many rows for matrix : ");
    scanf("%d",&n1);
    printf("\nHow many cols for matrix : ");
    scanf("%d",&n2);
    printf("\n\nA matrix : \n\n");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("A[%d][%d] = ",i,j);
            scanf("%d",&A[i][j]);
        }
    }
    printf("\n\nB matrix : \n\n");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("B[%d][%d] = ",i,j);
            scanf("%d",&B[i][j]);
        }
    }
    printf("\n\n\tA = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");

        printf("\t    ");
    }

    printf("\n\n\tB = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t    ");
    }
    getch();
}
