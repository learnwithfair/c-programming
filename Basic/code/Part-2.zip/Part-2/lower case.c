#include<stdio.h>
int main()
{

    char n,s;
    scanf("%c",&n);
        s=n-32;
    printf("%c\n",s);
}
