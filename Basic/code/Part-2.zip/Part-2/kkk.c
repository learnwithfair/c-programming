#include<stdio.h>
int main()
{
    int year,month,days;
    printf("inter days");
    scanf("%d",&days);
    year=days/365;
    days= days%365;
    month=days/30;
    days=days%30;
    printf("year=%d month=%d days=%d",year,month,days);

}
