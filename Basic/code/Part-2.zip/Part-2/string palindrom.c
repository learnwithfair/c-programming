#include<stdio.h>
int main()
{
    char str1[300];
    char str2[300];
    printf("Enter any string :");
    //input : madam
    gets(str1);
    int i,j,count=0,ra;
    i=0;
    while(str1[i]!='\0')
    {
        count++;
        i++;
    }



    for(i=count-1,j=0; i>=0; i--, j++)
    {
        str2[j]=str1[i];


    }
    str2[j]='\0';


    printf(" 1st string = %s\n",str1);
    printf("reverse string = %s\n",str2);
    ra=strcmp(str1,str2);
    if(ra==0)
    {
        printf("String is a palindrome\n");

    }
    else
    {
        printf("String is not a Palindrome\n");
    }

    return 0;

}
