#include<stdio.h>
enum test
{
    sat,sun,man,tus,wed,thu,fri
};

int main()
{
    enum test num,day;
    num=sat;
    day=wed;

    printf("%d\n",num);
    printf("%d\n",day);


}
