#include<stdio.h>
int main()
{
    char str1[]="Rahatul";
    printf("%s\n\n\n",str1);
    strrev(str1);
    printf("%s\n",str1);

}
