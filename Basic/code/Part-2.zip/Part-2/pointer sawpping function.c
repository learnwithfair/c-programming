#include<stdio.h>
void test(int *p1,int *p2)
{
    int tem;
    tem=*p1;
    *p1=*p2;
    *p2=tem;
    printf("x= %d\n",*p1);
    printf("y= %d\n",*p2);
}
int main()
{
    int x=6,y=4;
    test(&x,&y);
}
