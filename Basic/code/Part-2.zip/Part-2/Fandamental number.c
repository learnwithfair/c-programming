#include<stdio.h>
int main()
{
    int i,n,choice;
    printf("Choice the menu: \n");
    printf("1 prime numbers\n");
    printf("2 is not prime numbers\n");
    scanf("%d",&choice);

        switch(choice){
        case 1:
            {
            for(n=1; n<=100; n++)
        {
        for(i=2; i<=n; i++)
        {

            if(n%i==0)
            {
                break;
            }
        }
        if(n==i)
        {
            printf("%d Is the prime number\n",n);

        }
        break;
        }
        case 2:
            {
                for(n=1; n<=100; n++)
    {
        for(i=2; i<=n; i++)
        {

            if(n%i==0)
            {
                break;
            }
        }
          if(n!=i){
            printf("%d is not prime number\n",n);

        }
        }
        }
    }

        }
}
