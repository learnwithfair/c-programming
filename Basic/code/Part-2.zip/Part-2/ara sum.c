#include<stdio.h>
int main()
{
    int ara[100];
    int sum=0,i,n;
    double avg;
    printf("How many number : ");
    scanf("%d",&n);
    printf("Enter value for you want sum : ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&ara[i]);
    }
    for(i=0;i<n;i++)
    {
        sum=sum+ara[i];
        avg=sum/n;

    }
    printf("Total value of sum is %d\n",sum);
    printf("Total value of average is %.2lf\n",avg);

}
