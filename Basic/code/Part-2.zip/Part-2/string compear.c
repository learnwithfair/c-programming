#include<stdio.h>
int main()
{
    char str1[200],str2[200];
    int ln;
    printf("Enter 1st sentence  : ");
    gets(str1);
    printf("Enter 2nd sentence : ");
    gets(str2);

    ln=strcmp(str1,str2);
    if(ln==0)
    printf("same value\n");
    else{
        printf("Not match");
    }
}
