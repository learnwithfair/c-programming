#include<stdio.h>
void pow(int a,int b)
{
    int i,result =1;
    for(i=1;i<=b;i++)
    {
        result=result*a;
    }
    printf("Total number is %d",result);
    getch();
}
int main()
{
    int num1,num2;
    printf("Enter 1st number : ");
    scanf("%d",&num1);
    printf("Enter 2nd number : ");
    scanf("%d",&num2);
    pow(num1,num2);
}
