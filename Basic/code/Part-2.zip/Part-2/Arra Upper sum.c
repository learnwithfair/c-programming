#include<stdio.h>
int main()
{
    int A[10][10],B[10][10];
    int i,j,n1,n2,n3,n4,sum=0,sum1=0;
    printf("\nPlease Enter rows number for A matrix : ");
    scanf("%d",&n1);
    printf("\nPlease Enter cols number for A matrix : ");
    scanf("%d",&n2);
    while(n1!=n2)
    {
        printf("\nPlease Enter The 1st matrix Rows and Cols are same number for Upper sum\n");
        printf("\nPlease Enter rows number for A matrix : ");
        scanf("%d",&n1);
        printf("\nPlease Enter cols number for A matrix : ");
        scanf("%d",&n2);
    }
    printf("\nA matrix : \n\n");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf(" A[%d][%d] : ",i,j);
            scanf("%d",&A[i][j]);
        }
    }
    printf("\nThe matrix A : \n");
    printf("\n\n\t   A = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }



    printf("\nPlease Enter rows number for B matrix : ");
    scanf("%d",&n3);
    printf("\nPlease Enter cols number for B matrix : ");
    scanf("%d",&n4);


    while(n3!=n4)
    {
        printf("\nPlease Enter The 2nd matrix Rows and Cols are same number for Lower sum\n");
        printf("\nPlease Enter rows number for B matrix : ");
        scanf("%d",&n3);
        printf("\nPlease Enter cols number for B matrix : ");
        scanf("%d",&n4);
    }
    printf("\nB matrix : \n\n");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf(" B[%d][%d] : ",i,j);
            scanf("%d",&B[i][j]);
        }
    }
    printf("\nThe matrix B : \n");
    printf("\n\n\t   B = ");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }

    printf("\nTherefor The matrix A & B are : \n");

    printf("\n\n\t   A = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }
    printf("\n\n\t   B = ");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }

    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            if(j>i)
            {
                sum=sum+A[i][j];
            }
        }
    }
    printf("\nThe value of Upper Sum for A matrix = %d\n",sum);
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            if(i>j)
            {
                sum1=sum1+B[i][j];
            }
        }
    }
    printf("\nThe value of Lower Sum for B matrix = %d\n",sum1);
    getch();
}
