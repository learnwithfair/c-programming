#include<stdio.h>
int main()
{
    int n,row,col;
    scanf("%d",&n);
    for(row=1;row<=n;row++)
    {
        for(col=1;col<=n-row;col++)
        {
            printf("");
        }
        for(col=1;col<=n;col++)
        {
        if(row==1&&col==1||row==n&&col==n||row==1&&col==n||col==1&&row==n)
        {
            printf("* ");
        }
        else
        {
            printf("  ");
        }
        }
        printf("\n");
    }
}
