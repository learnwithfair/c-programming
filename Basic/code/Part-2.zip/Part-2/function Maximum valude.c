#include<stdio.h>
void max(int a[])
{
    int i;
    int max=a[0];
    for(i=1;i<5;i++)
    {
         if(a[i]>max)
        {
            max=a[i];
        }

    }
    printf("the maximum value is %d",max);
    getch();
}
int main()
{
    int ara[]={10,20,50,70,50};
    max(ara);
}
