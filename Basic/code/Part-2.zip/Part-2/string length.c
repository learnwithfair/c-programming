#include<stdio.h>
int main()
{
    char str[200];
    printf(" Please Enter any sentence : ");
    gets(str);
    int len=strlen(str);
    printf("%d",len);
    getch();
}
