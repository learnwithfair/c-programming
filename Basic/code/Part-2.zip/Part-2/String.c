#include<stdio.h>
int main()
{
    char str[]="My name is Rahatul islam";
    printf("%s",str);
    getch();

}
