#include<stdio.h>
int main ()
{
    int a=n,b=-n,sum;
    sum=a+b;
    printf("%d+%d=%d",a,b,sum);
}
