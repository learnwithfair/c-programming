#include<stdio.h>
union test1
{
   int x,y;
};

union test2
{
    int x;
    char n;
};

union test3
{
    int y;
    char p;
    double l;
    char n[10];
};

union test4
{
    int x;
    char y;
    float f;
    double d;
};

struct test5
{
    int x;
    char y[20];
};
int main()
{
    union test1 t1;
    union test2 t2;
    union test3 t3;
    union test4 t4;
    struct test5 t5;

    printf("test1 t1 %d\n",sizeof(t1));
    printf("test2 t2 %d\n",sizeof(t2));
    printf("test3 t3 %d\n",sizeof(t3));
    printf("test4 t4 %d\n",sizeof(t4));
    printf("test5 t5 %d\n",sizeof(t5));
    getch();

}
