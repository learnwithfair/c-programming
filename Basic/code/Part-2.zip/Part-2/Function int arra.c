#include<stdio.h>
void passing(int a[])
{

    int i,result;
    printf("The numbers of arra is ");
    for(i=0;i<3;i++)
    {

        result=a[i];
        printf("%d ",result);
    }

}
int main()
{
    int ara[300];
    int i,n;
    printf("How many number: ");
    scanf("%d",&n);
    printf("Enter numbers : ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&ara[i]);
    }
    passing(ara);

}
