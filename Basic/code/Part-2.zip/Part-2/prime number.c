#include<stdio.h>
int main()
{
    int n,i,ch,j,p;
    printf("Please Choice the menu :\n");
    printf("\n");
    printf("Such as condition 1 for press 1 digit or condition 2 for press 2 digit :-\n");
    printf("\t1) the prime numbers\n");
    printf("\t2) Not prime numbers\n");

    scanf("%d",&ch);
    switch(ch)
    {
    case 1:
    {
        printf("please enter (First) number for prime number.such as 0 to 100 here 0 is the First number :-\n");
        scanf("%d",&p);
        printf("please enter (Last) number for prime number.such as 0 to 100 here 100 is the Last number :-\n");
        scanf("%d",&n);
        for(i=p; i<=n; i++)
        {
            for(j=2; j<=i; j++)
            {
                if(i%j==0)
                {
                    break;
                }
            }
            if(i==j)
            {
                printf("\t\t\t%d is the prime number.\n",i);
            }
        }
        break;
    }
    case 2:
    {
        printf("please enter (First) number for not prime number.such as 0 to 100 here 0 is the First number :-\n");
        scanf("%d",&p);
        printf("please enter (Last) number for not prime number.such as 0 to 100 here 100 is the Last number :-\n");
        scanf("%d",&n);
        for(i=p; i<=n; i++)
        {
            for(j=2; j<=i; j++)
            {
                if(i%j==0)
                {
                    break;
                }
            }
            if(i!=j)
            {
                printf("\t\t\t%d is not the prime number.\n",i);
            }
        }
        break;
    }
    default:
        printf("\tThe number is not find in the menu.\n");
    }

    getch();
}
