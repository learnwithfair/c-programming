#include<stdio.h>
int main()
{
    int a,b,c;
    for (a=3;a<=3;a++){
        for(b=1;b<=3&&b!=a;b++){
            for(c=1;c<=3&&c!=b&&c!=a;c++){
                printf("%d, %d, %d\n",a,b,c);
            }
        }
    }
}
