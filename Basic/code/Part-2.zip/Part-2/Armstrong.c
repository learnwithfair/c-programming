#include<stdio.h>
int main()
{
    int num,n,r,sum=0;
    scanf("%d",&num);
    n=num;
    while(n!=0)
    {
        r=n%10;
        sum=sum+r*r*r;
        n=n/10;
    }
    if(num==sum)
        printf("The number is Armstrong number\n ");
    else
    {
        printf("The number is not Armstrong number\n ");
    }
}
// output : 153
