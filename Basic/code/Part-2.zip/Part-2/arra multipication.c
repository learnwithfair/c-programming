#include<stdio.h>
int main()
{
    int A[10][10],B[10][10],C[10][10];
    int i,j,n1,n2,n3,n4,k,sum=0;
    printf("How many rows for A matrix : ");
    scanf("%d",&n1);
    printf("\nHow many cols for A matrix : ");
    scanf("%d",&n2);
    printf("\n\nA matrix : \n\n");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("  A[%d][%d] = ",i,j);
            scanf("%d",&A[i][j]);
        }
    }
    printf("\nA matrix is :\n");

    printf("\n\n\tA = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");

        printf("\t    ");
    }

    printf("\nHow many rows for B matrix : ");
    scanf("%d",&n3);
    printf("\nHow many cols for B matrix : ");
    scanf("%d",&n4);
    while(n2!=n3)
    {
        printf("\n\nThe matrix value of Multipilication is Error.\n   Please Enter 1st matrix Row and 2nd matrix col are same number\n\n\n");
        printf("\nHow many rows for B matrix : ");
        scanf("%d",&n3);
        printf("\nHow many cols for B matrix : ");
        scanf("%d",&n4);
    }
    printf("\n\nB matrix : \n\n");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("  B[%d][%d] = ",i,j);
            scanf("%d",&B[i][j]);
        }
    }
    printf("\nB matrix is :\n");

    printf("\n\n\tB = ");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t    ");
    }
    printf("\n\n   Therefor the matrix A and B are : \n");
    printf("\n\n\tA = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");

        printf("\t    ");
    }

    printf("\n\n\tB = ");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t    ");
    }

    for(i=0; i<n1; i++)
    {
        for(j=0; j<n4; j++)
        {
            for(k=0; k<n2; k++)
            {
                sum=sum+A[i][k]*B[k][j];
            }
            C[i][j]=sum;
            sum=0;
        }
    }

    printf("\n\n   The Matrix value of Multiplied C is : \n");
    printf("\n\n\tC = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",C[i][j]);
        }
        printf("\n");
        printf("\t    ");
    }
    getch();
}
