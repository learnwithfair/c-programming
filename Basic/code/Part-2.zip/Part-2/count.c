#include<stdio.h>
int main()
{
    int count=0,n,num;
    scanf("%d",&num);
    n=num;
    while(n!=0)
    {
        n=n/10;
        count++;
    }
    printf("%d",count);
}
