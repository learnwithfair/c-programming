#include<stdio.h>
int main()
{
    int ara[100];
    int n,i;
    ara[0]=0;
    ara[1]=1;
    printf("How many number for Fibonacci serise : ");
    scanf("%d",&n);

    for(i=2;i<n;i++)
    {
        ara[i]=ara[i-2]+ara[i-1];
    }
    for(i=0;i<n;i++)
    {
        printf("%d ",ara[i]);
    }
}
