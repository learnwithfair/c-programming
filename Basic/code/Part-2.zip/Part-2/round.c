#include<stdio.h>
int main()
{
    double n,total;
    scanf("%lf",&n);
    total=trunc(n);
    printf("%.2lf",total);
}
