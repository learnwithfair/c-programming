#include<stdio.h>
int main()
{
    int lucas,n,num1=3,num2=-1,i,sum=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
        {
            lucas=num1+num2;
            num1=num2;
            num2=lucas;
        printf("%d ",lucas);
        sum=sum+lucas;
        }
        printf(" = %d",sum);

}

