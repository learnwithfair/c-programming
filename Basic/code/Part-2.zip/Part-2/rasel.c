#include<stdio.h>
int main()
{
    int a,c;
    printf("please enter input");
    scanf("%d",&a);
    if(a/2==0)
    printf("a=%d",a);

    else
    printf("c=%d",c);

}
