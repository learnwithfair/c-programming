#include<stdio.h>
int main()
{
    int A[10][10],B[10][10],C[10][10];
    int i,j,k,n1,n2,n3,n4,sum=0;
    printf("   Please Enter any Rows number for A matrix : ");
    scanf("%d",&n1);
    printf("\n   Please Enter any Cols number for A matrix : ");
    scanf("%d",&n2);
    printf("\nA matrix : \n");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("\n  A[%d][%d] : ",i,j);
            scanf("%d",&A[i][j]);
        }
    }
    printf("\nmatrix A : \n");
    printf("\n\n\t   A = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }

    printf("   \nPlease Enter any Rows number for B matrix : ");
    scanf("%d",&n3);
    printf("   \nPlease Enter any Cols number for B matrix : ");
    scanf("%d",&n4);
    while(n2!=n3)
    {
        printf("The Matrix value of Multiplied is Error.\n   Please Enter 1st matrix Cols and 2nd matrix Rows are same number.\n");
        printf("   \nPlease Enter any Rows number for B matrix : ");
        scanf("%d",&n3);
        printf("   \nPlease Enter any Cols number for B matrix : ");
        scanf("%d",&n4);
    }

    printf("\nB matrix : \n");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("\n  B[%d][%d] : ",i,j);
            scanf("%d",&B[i][j]);
        }
    }
    printf("\nmatrix B : \n");
    printf("\n\n\t   B = ");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }
    printf("\n\nTherefore The matrix A & B are : \n");

    printf("\n\n\t   A = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }

    printf("\n\n\t   B = ");
    for(i=0; i<n3; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }
        for(i=0; i<n1; i++)
    {
        for(j=0; j<n4; j++)
        {
            for(k=0; k<n2; k++)
            {
                sum=sum+A[i][k]*B[k][j];
            }
            printf("\n");
            C[i][j]=sum;
            sum=0;
        }
    }

    printf("The matrix Multiplied C : \n");
    printf("\n\n\t   C = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n4; j++)
        {
            printf("%d ",C[i][j]);
        }
        printf("\n");
        printf("\t       ");
    }


    getch();

}
