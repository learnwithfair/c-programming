#include<stdio.h>
int main()
{
    char str[200],str1[200];
    int len;
    printf("Enter your 1st string : ");
    gets(str);
    strcpy(str1,str);
    printf("str1 = %s\n",str);
    if(strcpy==0)
    {
        printf("string is a Fibonacci");

    }
    else
    {
         printf("string is not a Fibonacci");
    }

}
