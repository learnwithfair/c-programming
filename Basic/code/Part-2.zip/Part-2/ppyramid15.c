#include<stdio.h>
int main()
{
    int n,row,col;
    scanf("%d",&n);
    for(row=1;row<=n;row++)
    {
        for(col=1;col<=n;col++)
            if(row+col==n+1||row==col)
        {
            printf("* ");
        }
        else
        {
            printf("  ");
        }
        printf("\n");
    }
}
