#include<stdio.h>
int main()
{
    int row,col,n;
    printf("enter n= ");
    scanf("%d",&n);
    for(row=1;row<=n;row++)
    {
        if(row==2||row==3 ||col==2||col==3)
            printf(" ");
        else
            printf("*");
        printf("\n");
    }
}
