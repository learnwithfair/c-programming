#include<stdio.h>
int main()
{
    printf("my name is Rahatul islam");
}
