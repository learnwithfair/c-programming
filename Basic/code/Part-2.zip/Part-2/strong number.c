#include<stdio.h>
int main()
{
    int n,num,sum=0,r,i,fac;
    scanf("%d",&num);
    n=num;
    while(n!=0)
    {
        r=n%10;
        fac=1;
        for(i=1;i<=r;i++)
        {
            fac=fac*i;
        }
        sum=sum+fac;
        n=n/10;
    }
    if(num==sum)
    {
        printf("The number is Strong number\n");
    }

    else
    {
        printf("The number is not Strong number\n");
    }
}
