#include<stdio.h>
int main()
{
    char str1[300];
    printf("Enter any String : ");
    gets(str1);
    //strupr(str1);

    printf("Upper String is %s",toupper(str1));
}
