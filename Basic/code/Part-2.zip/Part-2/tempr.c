#include<stdio.h>
int main()
{
    int x,y;
    scanf("%d %d",&x,&y);
    double result;
    result=pow(x,y);
    printf("%.0lf",result);

}
