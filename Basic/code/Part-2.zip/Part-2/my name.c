#include<stdio.h>
int main()
{
    char n[100];
    gets(n);
    printf("My Name Is %s",n);
    getch();
}
