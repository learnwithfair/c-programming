#include<stdio.h>
int main()
{
    int i,n,num,fac=1;
    scanf("%d",&num);
    n=num;
    for(i=1;i<=n;i++)
    {
        fac=fac*i;
    }
    printf("%d",fac);

}
