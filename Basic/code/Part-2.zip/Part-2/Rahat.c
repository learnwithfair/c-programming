#include<stdio.h>
int main ()
{
    int a,b,sum;
    a=500,b=60;
    sum=a+b;
    printf("Sum is %d",sum);
}
