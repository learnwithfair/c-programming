#include<stdio.h>
int main()
{
    typedef char number;
    number ch;
    ch='A';
    number ch1;// টাইপডেফ  কোনো একটি ভেরিয়েবল কে ডাটা টাইপ হিসেবে কাজ করায়
    ch1='B';
    number ch2;
    ch2='C';
    number ch3;

    ch3='D';

    printf("%c\n",ch);
    printf("%c\n",ch1);
    printf("%c\n",ch2);
    printf("%c\n",ch3);
    getch();

}
