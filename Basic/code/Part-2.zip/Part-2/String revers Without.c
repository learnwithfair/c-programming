#include<stdio.h>
int main()
{
    char str1[300];
    char str2[30];
    printf("Please Enter any Sentence : ");
    gets(str1);
    int i,j,count=0;
      i=0;
    while(str1[i]!='\0')
    {
        count++;
        i++;
    }
    for(j=0,i=count-1;i>=0;i--,j++)
    {
        str2[j]=str1[i];

    }
    str2[j]='\0';
    printf("%s",str2);

}
