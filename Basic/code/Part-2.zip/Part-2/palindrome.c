#include<stdio.h>
int main()
{
    int n,r,num,sum=0;
    scanf("%d",&num);
    n=num;
    while(n!=0)
    {
        r=n%10;
        sum=sum*10+r;
        n=n/10;
    }
    if(sum==num)
    {
        printf("The number is palindrome number\n");
    }
    else
    {
        printf("The number is not palindrome\n");
    }

}
