
//সাভাবিক সংখ্যার যোগফল
#include<stdio.h>
int main()
{
    int i,n,s=0;
    printf("Enter the number : ");
    scanf("%d",&n);
    for(i=1; i<=n; i=i+1)

    {
        s=s+i;
    }
    printf("%d",s);
    return 0;
}
/*s=0+1, s=1
s=1+2, s=3
s=3+3, s=6
*/

