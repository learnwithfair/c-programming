#include<stdio.h>
int main()
{
    char str1[]="My name is Rahatul islam.";
    char str2[26];
    strcpy(str2,str1);
    printf("%s\n",str1);
    printf("%s",str2);
    getch();
}
