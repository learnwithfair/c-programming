#include<stdio.h>
int main()
{
    char n;
    scanf("%s",&n);
    printf("%s",n);
}
