#include <stdio.h>

int main()
{
    int n,row,col;

    printf("Enter the number of rows\n");
    scanf("%d", &n);
    /* printing top semi circular shapes of heart */
    for(row = n/2; row <= n; row+=2)
    {
        /* Printing Spaces */
        for(col = 1; col < n-row; col+=2)
        {
            printf(" ");
        }
        /* printing stars for left semi circle */
        for(col = 1; col <= row; col++)
        {
            printf("*");
        }
        /* Printing Spaces */
        for(col = 1; col <= n-row; col++)
        {
            printf(" ");
        }
        /* printing stars for right semi circle */
        for(col = 1; col <= row; col++)
        {
            printf("*");
        }
        /* move to next row */
        printf("\n");
    }

    /* printing inverted start pyramid */
    for(row = n; row >= 1; row--)
    {
        for(col = row; col < n; col++)
        {
            printf(" ");
        }
        for(col = 1; col <= (row*2)-1; col++)
        {
            printf("*");
        }
        /* move to next row */
        printf("\n");
    }

    return 0;
}
