#include<stdio.h>
void main()
{
    char n,x;
    scanf("%c",&n);
    if(n>='a'&&n<='z'){
     x='A'+(n-'a');
     printf("%c",x);
    }
    else
    printf("%c",n);
}
