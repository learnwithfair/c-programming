#include<stdio.h>
int main()
{
    int n;
    double tem, conversion;
    printf("Tempreture conversion choice menu : \n");
    printf("1) Farenheit to Celcius tempretur : \n");
    printf("2) Celcious to Fahrenheit tempreture : \n");
    scanf("%d",&n);
    switch(n)
    {
        case 1:{
        printf("Enter Fahrenheit Tempreture : \n");
        scanf("%lf",&tem);
        conversion=5*(tem-32)/9;
        printf("Celcius Tempreture is %.2lf\n",conversion);
        break;
        }
        case 2:{
        printf("Enter Celcious Tempreture : \n");
        scanf("%lf",&tem);
        conversion=(9*tem/5)+32;
        printf("Fahrenheit Tempreture is %.2lf\n",conversion);
        break;
        }
        default:{
        printf("not currect\n");
        }

    }
}
