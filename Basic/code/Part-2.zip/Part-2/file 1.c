#include<stdio.h>
int main()
{
    int a,b,c;
    printf("inter the three number");
    scanf("%d %d %d",&a,&b,&c);
    if(a>c)
    {
        printf("a=%d",a);

     }
    else
    {
        printf("b=%d",b);

    }
  }



    else
    {

      if(c>b);
      {
          printf("c=%d",c);

       }
       else
       {
           printf("b=%d",b);

         }
     }

}
