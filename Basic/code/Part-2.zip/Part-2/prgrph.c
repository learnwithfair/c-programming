#include<stdio.h>
int main()
{
    char n[ 200];

    gets(n);
    printf("%s\n",n);
    getch();
}
