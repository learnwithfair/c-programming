#include<stdio.h>
int main()
{
    char str[300];
    char ch;
    int capital,small,digit,i,other,word;
    printf("Enter any String : ");
    gets(str);
    i=capital=small=digit=other=word=0;
    while(str[i]!='\0')
    {
        if (str[i]>=65&&str[i]<=90)
            capital++;
        else if (str[i]>=97&&str[i]<=122)
            small++;
        else if(str[i]>=48&&str[i]<=57)
            digit++;
    else
        other++;

            i++;
    }
    printf("The String in Capital number is %d\n",capital);
    printf("The String in small number is %d\n",small);
    printf("The String in Digit number is %d\n",digit);
    printf("The String in Other number is %d\n",other);


}
