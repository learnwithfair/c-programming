#include<stdio.h>
int main()
{
    int x=9,y=5,tem=0;
    int *ptr1;
    ptr1=&x;
    int *ptr2;
    ptr2=&y;
    tem=*ptr1;
    *ptr1=*ptr2;
    *ptr2=tem;
    printf("x= %d\n",*ptr1);
    printf("y= %d\n",*ptr2);

}
