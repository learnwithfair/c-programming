#include<stdio.h>
int main()
{
    int A[10][10],B[10][10],C[10][10];
    int i,j,n1,n2,n3,n4,sum=0,k,l;
    printf("How many rows for A matrix : ");
    scanf("%d",&n1);
    printf("\nHow many cols for A matrix : ");
    scanf("%d",&n2);
    printf("\n\nA matrix : \n\n");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("  A[%d][%d] = ",i,j);
            scanf("%d",&A[i][j]);
        }
    }

    printf("\n\n\tA = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");

        printf("\t    ");
    }

    printf("\nHow many rows for B matrix : ");
    scanf("%d",&n3);
    printf("\nHow many cols for B matrix : ");
    scanf("%d",&n4);


    while(n1!=n3||n2!=n4)
    {
        printf("\n\nThe matrix sum = Error \n\n   Please Enter 1st & 2nd matrix same rows and Col \n");
        printf("\nHow many rows for B matrix : ");
        scanf("%d",&n3);
        printf("\nHow many cols for B matrix : ");
        scanf("%d",&n4);
    }
    printf("\n\nB matrix : \n\n");
    for(k=0; k<n3; k++)
    {
        for(l=0; l<n4; l++)
        {
            printf("  B[%d][%d] = ",i,j);
            scanf("%d",&B[k][l]);
        }
    }

    printf("\n\n\tB = ");
    for(k=0; k<n3; k++)
    {
        for(l=0; l<n4; l++)
        {
            printf("%d ",B[k][l]);
        }
        printf("\n");
        printf("\t    ");
    }
    printf("\n\n   Therefore A & B Matrix are : \n");
    printf("\n\n\tA = ");
    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");

        printf("\t    ");
    }

    printf("\n\n\tB = ");
    for(k=0; k<n3; k++)
    {
        for(l=0; l<n4; l++)
        {
            printf("%d ",B[k][l]);
        }
        printf("\n");
        printf("\t    ");
    }

    printf("\n\n  A & B Matrix value of Sum, C : \n");
    printf("\n\n\tC = ");

    for(i=0; i<n1; i++)
    {
        for(j=0; j<n2; j++)
        {
            for(k=0;k<n3;k++)
            {
                for(l=0;l<n4;l++)
                {
                    C[i][j]=A[i][j]+B[k][l];
                    printf("%d ",C[i][j]);
                }
            }
        }
        printf("\n");
        printf("\t    ");
    }

    getch();
}


