#include<stdio.h>
int main()
{
    char lower,upper;
    printf("Enter any lower key : ");
    scanf("%c",&lower);
    upper =toupper(lower);
    printf("the upper key is : %c\n",upper);
}
