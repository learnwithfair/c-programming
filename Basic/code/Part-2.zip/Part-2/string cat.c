#include<stdio.h>
int main()
{
    char str1[]="Rahatul Islam";
    char str2[]=" Rahat";
    strcat(str1,str2);
    printf("%s",str1);
    getch();
}
