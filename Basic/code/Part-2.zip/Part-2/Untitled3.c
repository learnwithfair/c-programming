#include<stdio.h>
int main ()
{
    int n;
    double x;
    x=10.5;
    n=(int) x;
    printf("value of n is %d\n",n);
    printf("value of x is %lf\n",x);
}
