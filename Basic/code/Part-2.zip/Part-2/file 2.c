#include<stdio.h>
int main()
{
    FILE *p;
    char n[20]="Rahatul islam";
    p=fopen("text.htx","w");
    if(n==NULL)
    printf("File doesnot exit \n");
    else{
        printf("File is exit \n");
        fclose(n);
    }


}

