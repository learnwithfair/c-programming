#include<stdio.h>
struct person

{
    int age;
    float salary;
};
int main()
{
    struct person person1,person2;
    printf("Information of person1 : \n");
    printf("Enter age for person 1 :");
    scanf("%d",&person1.age);
    printf("Enter salary for person 1 :");
    scanf("%f",&person1.salary);

    printf("\n\nInformation of person2 : \n");
    printf("Enter age for person 2 :");
    scanf("%d",&person2.age);
    printf("Enter salary for person 2 :");
    scanf("%f",&person2.salary);

    printf("\n\nInformation of person1 : \n");
    printf("the person1 age is %d\n",person1.age);
    printf("the person1 salary is %.2f\n",person1.salary);

    printf("\n\nInformation of person2 : \n");
    printf("the person2 age is %d\n",person2.age);
    printf("the person2 salary is %.2f\n",person2.salary);
    getch();
}
