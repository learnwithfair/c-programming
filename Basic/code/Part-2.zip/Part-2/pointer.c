#include<stdio.h>
int main()
{
    int x=5;
    int *t;
    t=&x;
    printf("%d\n",x);
    printf("%d\n",&x);
    printf("%d\n",&t);
    printf("%d\n",*t);
}
