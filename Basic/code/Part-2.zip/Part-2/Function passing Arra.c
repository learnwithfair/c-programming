#include<stdio.h>
void passing(char a[300])
{
    int i;
    char result;
    i=0;
    while(a[i]!='\0')
    {
        result=a[i];
        printf("%c",result);
        i++;
    }
}
int main()
{
    char ara[300];
    printf("Enter any sentence : ");
    gets(ara);
    passing(ara);

}
