#include<stdio.h>
int main()
{
    double i,n;
    scanf("%d",&n);
    for (i=.33;i<=n;i=i+2){
      printf("%lf\n",i);
    }
    //x=exp(a);

}
