#include<stdio.h>
struct person
{
    int age;
    float salary;
};
int main()
{
    struct person person1={27,2457.24};
    struct person person2,person3;
    person2=person1;
    person3.age=25;
    person3.salary=2524.56;

    printf("\n\nInformation of person1 : \n");
    printf("the person1 age is %d\n",person1.age);
    printf("the person1 salary is %.2f\n",person1.salary);

    printf("\n\nInformation of person2 : \n");
    printf("the person2 age is %d\n",person2.age);
    printf("the person2 salary is %.2f\n",person2.salary);

    printf("\n\nInformation of person3 : \n");
    printf("the person3 age is %d\n",person3.age);
    printf("the person3 salary is %.2f\n",person3.salary);
    getch();
}
