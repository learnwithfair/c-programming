#include<stdio.h>
int main()
{
    int p;
    printf("Enter any Ascii value :");
    scanf("%d",&p);

    printf("The Ascii character is %c\n",p);
    return 0;
}
