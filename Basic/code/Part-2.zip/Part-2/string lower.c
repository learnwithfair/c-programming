#include<stdio.h>
#include<string.h>
int main()
{
    char str[300];
    printf("Enter any string : ");
    gets(str);
    strlwr(str);
    printf("Lower string is %s",str);
}
