#include<stdio.h>
#include<math.h>
int main()
{
    double x,result,s;
    scanf("%lf",&x);
    s=x*(3.1416/180);
    result=tan(s);
    printf("%.3lf\n",result);

    return 0;
}
