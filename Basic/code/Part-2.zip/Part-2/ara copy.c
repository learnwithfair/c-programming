#include<stdio.h>
int main()
{
    int ara1[5]= {10,20,30,40,60};
    int i,ara2[5];
    printf("Arra1 value : ");
    for(i=0; i<5; i++)
    {
        printf("%d ",ara1[i]);
    }
    for(i=0;i<5;i++)
    {
        ara2[i]=ara1[i];
    }
    printf("\nArra2 value : ");
    for(i=0;i<5;i++)
    {
        printf("%d ",ara2[i]);
    }
    getch();
}
