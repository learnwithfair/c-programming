#include<stdio.h>
int main()
{
    int ara[14]={10,20,10,30,50,4,2,78,15,45,14,25,45,65};
    int n,i,a;
    scanf("%d",&n);
    for(i=0;i<14;i++)
    {
       a=ara[i];



    if(a==n)
        printf("The number is %d found in the ara \n",n);

        else
        {
            printf("The number not is %d found in the ara \n",n);
        }
    }


}
