
#include<stdio.h>
int main()
{
    int arra[20][20],arra2[20][20];
    int r1,c1,i,j,r2,c2,k,sum=0,sum1;
    printf("Enter row for A Matrix : ");
    scanf("%d",&r1);

    printf("Enter column for A Matrix : ");
    scanf("%d",&c1);
    printf("Enter elements for A Matrix : \n");
    for(i=0;i<r1;i++)
    {
        printf("Enter the elements of %d Row : \n",i+1);
        for(j=0;j<c1;j++)
        {
            printf("A[%d][%d] = ",i,j);
            scanf("%d",&arra[i][j]);
        }
    }
    //

    printf("\nThe matrix is A = ");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            printf("%d ",arra[i][j]);
        }
        printf("\n\t\t  ");
    }
    //B

    printf("\nEnter row for B Matrix : ");
    scanf("%d",&r2);

    printf("Enter column for B Matrix : ");
    scanf("%d",&c2);
    printf("Enter elements for B Matrix: \n");
    for(i=0;i<r2;i++)
    {
        printf("Enter the elements of %d Row : \n",i+1);
        for(j=0;j<c2;j++)
        {
            printf("B[%d][%d] = ",i,j);
            scanf("%d",&arra2[i][j]);
        }
    }
    //

    printf("\nThe matrix is B = ");
    for(i=0;i<r2;i++)
    {
        for(j=0;j<c2;j++)
        {
            printf("%d ",arra2[i][j]);
        }
        printf("\n\t\t  ");
    }
    //add
    printf("\nThe Matrix A & B Adds : \n");
    printf("A + B = ");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            sum1=arra[i][j]+arra2[i][j];
            printf("%d ",sum1);

        }
        printf("\n\t");
    }


    //mul
    printf("\nThe Multiplies A & B matrix : \n");
    printf("A * B = ");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c2;j++)
        {
            for(k=0;k<c1;k++)
            {
                sum=sum+arra[i][k]*arra2[k][j];
            }
            printf("%d ",sum);
            sum=0;
        }
        printf("\n\t");
    }
    getch();

}
