#include<stdio.h>
int main()
{
    int n;
    printf("Enter any number : ");
    scanf("%d",&n);
    printf("the Octal number is %o\n",n);
    getch();
}
