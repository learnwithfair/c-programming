#include<stdio.h>
int main()
{
    int n,i,a=1,sum=0;
    printf("How many term : ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum= sum+a;
        a=a+2;
    }
    printf("Sum : %d\n",sum);
    getch();
}
