#include<stdio.h>
int main()
{
    int n,day,month,year;
    scanf("%d",&n);
    year=n/365;
    n=n%365;
    month=n/30;
    n=n%30;
    day=n;
    printf("1 no=\t%d-%d-%d\n",day,month,year);
    printf("2 no=\t%d/%d/%d\n",day,month,year);
    printf("3 no=\t%d %d %d\n",day,month,year);
    printf("4 no=\t%d,%d,%d\n",day,month,year);
    return 0;
}
