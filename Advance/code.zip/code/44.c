#include<stdio.h>
int main()
{
    int arra[10],n,i,sum=0;
    double avg;
    printf("Enter any number : ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&arra[i]);
    }
    for(i=0;i<n;i++)
    {
        sum=sum+arra[i];
    }
    avg=sum/(double) n;
    printf("Average value is : %.2lf",avg);
}
