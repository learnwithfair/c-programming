#include<stdio.h>
int main()
{
    double r,area,pi=3.1416;
    printf("Enter any radius : ");
    scanf("%lf",&r);
    area=pi*r*r;
    printf("Circle area is : %.2lf\n",area);
    getch();
}
