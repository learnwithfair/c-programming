#include<stdio.h>
int main()
{
    int arra[20][20];
    int r,c,i,j;
    printf("Enter any row : ");
    scanf("%d",&r);

    printf("Enter any row : ");
    scanf("%d",&c);
    printf("Enter any elements : \n");
    for(i=0;i<r;i++)
    {
        printf("Enter the elements of %d Row : \n",i+1);
        for(j=0;j<c;j++)
        {
            printf("A[%d][%d] = ",i,j);
            scanf("%d",&arra[i][j]);
        }
    }
    //

    printf("\nThe matrix is A = ");
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            printf("%d ",arra[i][j]);
        }
        printf("\n\t\t  ");
    }
    getch();

}
