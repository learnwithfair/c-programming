#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    printf("%o",n);
    return 0;
}
