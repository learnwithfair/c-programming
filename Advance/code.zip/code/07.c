#include<stdio.h>
int main()
{
    int n1,n2,or;
    printf("Enter two number : ");
    scanf("%d%d",&n1,&n2);
    or=n1^n2;
    printf("Bitwise exclusive OR is %d\n",or);
    getch();
}
