#include<stdio.h>
int main()
{
    int num1,num2,tem,n1,n2,gcd,lcd;
    printf("Enter First number : ");
    scanf("%d",&num1);
    printf("Enter Second number : ");
    scanf("%d",&num2);
    n1=num1;
    n2=num2;
    while(n2!=0)
    {
        tem=n1%n2;
        n1=n2;
        n2=tem;
    }
    gcd=n1;
    lcd=(num1*num2)/gcd;
    printf("The LCD value is %d\n",lcd);
    getch();
}
