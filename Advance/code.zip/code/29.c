#include<stdio.h>
int main()
{
    int row,col,n,count=0;
    printf("How many term : ");
    scanf("%d",&n);
    for(row=1; row<=n; row++)
    {
        for(col=1; col<=n-row; col++)
            printf("  ");
        for(col=1; col<=row; col++)
        {
            count++;
            if(count>9)
                printf("%d ",count%10);
            else
                printf("%d ",count);
        }
        for(col=1; col<=row-1; col++)
        {
            count--;
            if(count>9)
                printf("%d ",count%10);
            else
                printf("%d ",count);
        }
        printf("\n");
    }
    count=count-2;
    for(row=n-1; row>=1; row--)
    {
        for(col=1; col<=n-row; col++)
        {
            printf("  ");
        }
        for(col=1; col<=row; col++)
        {
            count++;
            if(count>9)
                printf("%d ",count%10);
            else
                printf("%d ",count);
        }
        for(col=row-1; col>=1; col--)
        {
            count--;
            if(count>9)
                printf("%d ",count%10);
            else
                printf("%d ",count);
        }
        printf("\n");
        count=count-2;
    }
    getch();
}
