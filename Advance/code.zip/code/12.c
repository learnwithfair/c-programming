#include<stdio.h>
int main()
{
    int mark;
    printf("Enter any mark : ");
    scanf("%d",&mark);
    printf("Division ");
    if(mark>=80&&mark<=100)
        printf("A+");
    else if(mark>=70&&mark<80)
        printf("A");
    else if(mark>=60&&mark<70)
        printf("A-");
    else if(mark>=50&&mark<60)
        printf("B");
    else if(mark>=40&&mark<50)
        printf("C");
    else if(mark>=30&&mark<40)
        printf("D");
    else
        printf("Fall");
    getch();
}
