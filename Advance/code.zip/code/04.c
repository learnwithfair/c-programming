#include<stdio.h>
int main()
{
    int n,n2;
    printf("Enter any number : ");
    scanf("%d%d",&n,&n2);
    printf("Rem= %d\n",n%n2);
}
