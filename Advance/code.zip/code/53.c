#include<stdio.h>
int main()
{
    char str[20];
    printf("Enter string : ");
    gets(str);
    strrev(str);
    printf("Revers order is %s",str);
    getch();
}
