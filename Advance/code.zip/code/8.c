#include<stdio.h>
int main()
{
    int n,result;
    scanf("%d",&n);
    result=n&7;
    printf("%d",result);

}

