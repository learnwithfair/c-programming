#include<stdio.h>
int main()
{
    int n1=-1,n2=1,tem,n,i;
    printf("Enter any number : ");
    scanf("%d",&n);
    for(i=0;i<=n;i++)
    {
        tem=n1+n2;
        if(tem==n)
        {
            break;
        }
        n1=n2;
        n2=tem;
    }
    if(tem==n)
        printf("Fibonacci");
    else
        printf("Not Fibonacci");
}

