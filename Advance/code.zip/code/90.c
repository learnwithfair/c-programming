#include<stdio.h>
int main()
{
    int n,i,R=1;
    scanf("%d",&n);
    int *p;
    p=&n;
    for(i=1;i<=*p;i++)
    {
        R=R*i;
    }
    printf("%d",R);
}

