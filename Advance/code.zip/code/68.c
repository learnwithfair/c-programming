#include<stdio.h>
struct a
{
    char name[20];
    int roll,mark;
};
int main()
{
    struct a a[20],temp;
    int i,j,n;
    FILE *fp;
    fp=fopen("Asha.text","r");
    n=0;
    while(fscanf(fp,"%s%d%d",a[n].name,&a[n].roll,&a[n].mark)!=EOF)
        n++;
    for(i=n-1; i>=0; i--)
    {
        for(j=0; j<i; j++)
        {
            if(a[j].mark<a[j+1].mark)
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }


    printf("\nName\tRoll\tMark");
    printf("\n------------------\n");

    for(i=0; i<n; i++)
    {
        printf("%s    %d    %d\n",a[i].name,a[i].roll,a[i].mark);
    }
    getch();
}

