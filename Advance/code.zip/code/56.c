#include<stdio.h>
int main()
{
    char str[30];
    int len,i;
    printf("Enter name : ");
    gets(str);
    len=strlen(str);
    printf("Revers name is : ");
    for(i=len-1;i>=0;i--)
    {
        printf("%c ",str[i]);
    }
    getch();
}
