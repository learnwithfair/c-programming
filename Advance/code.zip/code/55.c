#include<stdio.h>
int main()
{
    char arra[200];
    printf("Enter any Lower case text : ");
    gets(arra);
    strupr(arra);
    printf("The Upper case text is %s\n",arra);
    return 0;
}
