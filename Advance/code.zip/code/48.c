#include<stdio.h>
int main()
{
    int i,n,arra[200],p,pos=0;
    printf("How many number : ");
    scanf("%d",&n);
    printf("Enter array : ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arra[i]);
    }

    printf("Array series is : ");
    for(i=0;i<n;i++)
    {
        printf("%d ",arra[i]);
    }
    //
     printf("\nEnter the value for find the position in array: ");
    scanf("%d",&p);
     for(i=0;i<n;i++)
    {
        if(arra[i]==p)
        {
            pos++;
            break;
        }

    }
    if(pos==0)
        printf("The value is not find in array.");

    else
        printf("The value %d is find at position %d in array.",p,i+1);
    getch();
}
