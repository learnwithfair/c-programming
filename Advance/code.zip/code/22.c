#include<stdio.h>
int main()
{
    int n,a=1,b=3,c=5,d=7,sum=0,i;
    printf("How many term : ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=sum+a*b*c*d;
        a=a+2;
        b=b+2;
        c=c+2;
        d=d+2;
    }
    printf("Sum = %d\n",sum);
    getch();
}
