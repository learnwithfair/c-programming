#include<stdio.h>
int main()
{
    int n,r,r1,i,result=1,result2=1,total,j,n1;
    printf("Enter n : ");
    scanf("%d",&n1);
    printf("Enter r : ");
    scanf("%d",&r1);
    n=n1;
    r=r1;
    while(r!=0)
    {
        result=result*n;
        n--;
        r--;
    }
    for(j=1; j<=r1; j++)
    {
        result2=result2*j;
    }
    total=result/result2;
    printf("\n\n%dC%d = %d",n1,r1,total);

    getch();
}
