#include<stdio.h>
int main()
{
    int n,a=2,b=5,c=8,sum=0,i;
    printf("How many term : ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=sum+a*b*c;
        a=a+3;
        b=b+3;
        c=c+3;
    }
    printf("Sum = %d\n",sum);
    getch();
}
