#include<stdio.h>
int main()
{
    int n,a=1,b=3,sum=0,i;
    printf("How many number : ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=sum+a*b;
        a=a+2;
        b=b+2;
    }
    printf("Sum = %d\n",sum);
    getch();
}
