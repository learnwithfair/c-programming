#include<stdio.h>
int main()
{
    int A[10][10],B[10][10],C[10][10];
    int i,r1,c1,r2,c2,j,k,sum=0;
    printf("How many A matrix row & Column : ");
    scanf("%d%d",&r1,&c1);
    printf("How many B matrix row & Column : ");
    scanf("%d%d",&r2,&c2);
    printf("Enter elements for A matrix : ");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            scanf("%d",&A[i][j]);
        }
    }
    //
    printf("Enter elements for B matrix : ");
    for(i=0;i<r2;i++)
    {
        for(j=0;j<c2;j++)
        {
            scanf("%d",&B[i][j]);
        }
    }
    //
    printf(" Multiplies C matrix : \n");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c2;j++)
        {
            for(k=0;k<r2;k++)
            {
                sum=sum+A[i][k]*B[k][j];
            }
            printf("%d ",sum);
            sum=0;
        }

        printf("\n");
    }
    getch();
}
