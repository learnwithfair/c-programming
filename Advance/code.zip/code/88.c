#include<stdio.h>
int main()
{
    double num1,num2,R;
    scanf("%lf %lf",&num1,&num2);
    double *p1,*p2;
    p1=&num1;
    p2=&num2;
    if(*p1>*p2)
    printf("%.3lf",*p1);
    else
    printf("%.3lf",*p2);
}


