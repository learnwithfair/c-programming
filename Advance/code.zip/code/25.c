#include<stdio.h>
int main()
{
    int row,col,n;
    printf("How many term : ");
    scanf("%d",&n);
    for(row=n;row>=1;row--)
    {
        for(col=row;col>=1;col--)
        {
            printf("%d ",col%2);
        }
           printf("\n");
    }
    getch();
}
