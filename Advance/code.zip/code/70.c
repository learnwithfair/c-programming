#include<stdio.h>
struct p
{
    char name[20];
    int phone;
};
int main()
{
    struct p p[20];
    char na[20];
    int i,j,n,ph;
    FILE *f;
    f=fopen("Jothy.text","r");
    n=0;
    while(fscanf(f,"%s %d",p[n].name,&p[n].phone)!=EOF)
        n++;

    printf("Enter phone number : ");
    scanf("%d",&ph);
    for(i=0; i<n; i++)
    {
        if(p[i].phone==ph)
            printf("%s\n",p[i].name);
    }



    printf("Enter name : ");
    scanf("%s",na);
    for(i=0; i<n; i++)
    {

        if(strcmp(p[i].name,na)==0)
            printf("\n%d",p[i].phone);

    }

    getch();
}

