#include<stdio.h>
int main()
{
    int n,i;
    printf("Enter any number : ");
    while((scanf("%d",&n))!=EOF)
    {
        for(i=2;i<=n;i++)
    {
        if(n%i==0)
        {
             break;
        }


    }
    if(n==i)
        printf("This number is  Prime number \n");
    else
        printf("This number is not Prime number \n");
    }

        getch();
}
