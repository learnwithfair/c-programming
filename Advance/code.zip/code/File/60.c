#include<stdio.h>
int main()
{
    int n,i,j;
    FILE *R;
    printf("How many term : ");
    scanf("%d",&n);

    R=fopen("60.text","w");
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            fprintf(R,"%d ",i);
        }
        fprintf(R,"\n");
    }
    printf("Data is stored\n");
    getch();
}
