#include<stdio.h>
int main()
{
    char ch;
    FILE *R;
    R=fopen("61.text","r");

    while(!feof(R))
    {

        ch=fgetc(R);
        if(ch>='a'&&ch<='z')
        {
            printf("%c",ch-32);
        }
        else
            printf("%c",ch);

    }
    fclose(R);
    getch();
}
