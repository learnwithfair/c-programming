#include<stdio.h>
void display(char arra[200])
{
    char tem;
    int i,j,len;
    printf("String is %s\n",arra);
    len=strlen(arra);
    for(i=0;i<len-1;i++)
    {
        for(j=i+1;j<len;j++)
        {
            if(arra[i]>arra[j])
            {
                tem=arra[i];
                arra[i]=arra[j];
                arra[j]=tem;
            }
        }
    }
    printf("The sorts  String is %s\n",arra);
    strrev(arra);
    printf("The string revers is %s\n",arra);
}
int main()
{
    char arra[200];
    printf("Enter any String : ");
    gets(arra);
    display(arra);
    getch();

}
