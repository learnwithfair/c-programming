#include<stdio.h>
int main()
{
    int n,row,col,count=0,r,n1;
    printf("How many numbers : ");
    scanf("%d",&n1);
    printf("\n");
    n=n1;
    for(row=1;row<=n;row++)
    {
        for(col=1;col<=n-row;col++)
        {
            if(row>3)
            printf("  ");

        }
        for(col=1;col<=row;col++)
        {
            count=count+1;
            if(row>3)
            printf("%d ",count);
            else
                printf("%d",count);
        }
        for(col=row-1;col>=1;col--)
        {
            count=count-1;
            if(row>3)
            printf("%d ",count);
            else
                printf("%d",count);
        }
        printf("\n");
    }
    //
     count=n1-2;
        for(row=n-1;row>=1;row--)
    {
        for(col=1;col<=n-row;col++)
        {
            printf("  ");

        }
        for(col=row;col>=1;col--)
        {
            count=count+1;
            printf("%d ",count);

        }

        for(col=row-1;col>=1;col--)
        {
            count=count-1;
            printf("%d ",count);
        }
        printf("\n");
        count=count-2;
    }
    getch();
}
