#include<stdio.h>
int main()
{
    double x,n;
    scanf("%lf",&x);
    n=sqrt(x);
    printf("n = %.lf",n);
    return 0;
}
