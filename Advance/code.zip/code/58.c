#include<stdio.h>
int main()
{
    char str[200];
    int i,j;
    printf("Enter any String : ");
    gets(str);
    for(i=65;i<=122;i++)
    {
        j=0;
        while(str[j]!='\0')
        {
            if(str[j]==i)
        {
            printf("%c ",str[j]);
        }
        j++;
        }
    }
    getch();

}

