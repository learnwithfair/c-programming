#include<stdio.h>
struct student{
char name[20];
int mark;
int roll;
};
int main()
{
    struct student *p;
    int n,i;
    printf("How many student : ");
    scanf("%d",&n);

    p=(struct student*)malloc(sizeof(struct student));
    for(i=0;i<n;i++)
    {
        printf("Enter name : ");
        scanf("%s",(p+i)->name);
        printf("Enter Roll : ");
        scanf("%d",&(p+i)->roll);
        printf("Enter mark : ");
        scanf("%d",&(p+i)->mark);
    }
    for(i=0;i<n;i++)
    {
        printf("\n\n\nStudent information : \n");
        printf("name : ");
        printf("%s\n",(p+i)->name);
        printf("Roll : ");
        printf("%d\n",(p+i)->roll);
        printf("mark : ");
        printf("%d\n",(p+i)->mark);
    }

}
