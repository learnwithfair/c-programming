#include<stdio.h>
int main()
{
    int num1=-1,num2=1,fibo,i,n;
    printf("How many term : ");
    scanf("%d",&n);
    i=0;
    printf("Fibonacci series  is : ");
    while(i<n)
    {
        fibo=num1+num2;
        printf("%d ",fibo);
        num1=num2;
        num2=fibo;
        i++;
    }
    getch();
}
