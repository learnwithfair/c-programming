#include<stdio.h>
int main()
{
    char str[20],ch;
    int i,vowel=0,consonant=0,digit=0,space=0,line=0,
    other=0;
    printf("Enter String : ");
    gets(str);
    i=0;
    while((ch=str[i])!='\0')
    {
        if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||
           ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
            vowel++;
        else if(ch>='A'&&ch<='Z'||ch>='a'&&ch<='z')
            consonant++;
        else if(ch>='1'&&ch<='9')
            digit++;
        else if(ch==' ')
            space++;
            else if(ch=='.')
            line++;
        else
            other++;
            i++;
    }
    space++;
    printf("Vowel number is : %d\n",vowel);
    printf("Consonant number is : %d\n",consonant);
    printf("Digit number is : %d\n",digit);
    printf("Space number is : %d\n",space);
    printf("Other number is : %d\n",other);
    printf("line number is : %d\n",line);
    getch();
}
