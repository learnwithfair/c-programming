#include<stdio.h>
double display(double a,double b)
{
    double r;
    r=a*b;
    return r;


}
int main()
{
    double length,width,area;
    printf("Enter any length : ");
    scanf("%lf",&length);
    printf("Enter any width : ");
    scanf("%lf",&width);
    area=display(length,width);

    printf("Rectangle Area is %.2lf\n",area);

}
