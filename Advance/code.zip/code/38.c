#include<stdio.h>
int main()
{
    int n,r,r1,i,result=1,n1;
    printf("Enter n : ");
    scanf("%d",&n1);
    printf("Enter r : ");
    scanf("%d",&r1);
    n=n1;
    r=r1;
    while(r!=0)
    {
        result=result*n;
        n--;
        r--;
    }
    printf("%dP%d = %d",n1,r1,result);
    getch();


}
