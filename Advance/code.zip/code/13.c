#include<stdio.h>
int main()
{
    int mark;
    printf("Enter any mark : ");
    scanf("%d",&mark);
    if(mark>=60)
        printf("First Division\n");
    else if(mark>=48)
        printf("Second Division\n");
    else if (mark>=36)
        printf("Third division\n");
    else
    printf("Fall");
    getch();

}
