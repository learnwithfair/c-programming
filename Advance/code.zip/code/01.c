#include<stdio.h>
int main()
{
    char ch;
    printf("Enter any lower case : ");
    scanf("%c",&ch);
    printf("Upper case is %c\n",ch-32);
    getch();
}
