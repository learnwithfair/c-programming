#include<stdio.h>
int main()
{
    int n,i,p;
    printf("Enter any term : ");
    scanf("%d",&n);
    printf("Prime numbers are : ");
    for(p=1; p<=n; p++)
    {
        for(i=2; i<=p; i++)
        {
            if(p%i==0)
            {
                break;
            }


        }
        if(p==i)
            printf("%d ",p);

    }
    getch();

}
