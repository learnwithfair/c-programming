#include<stdio.h>
int main()
{
   int i;
   FILE *file;
    file=fopen("RRR.text","w");
    for(i=1;i<=10;i++)
    {
        fprintf(file,"%d\n",i);
    }
    printf("Data is stored\n");
    getch();
}
