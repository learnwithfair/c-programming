#include<stdio.h>
double display(double r)
{
    double ra,pi=3.1416;
    ra=pi*r*r;
    return ra;


}
int main()
{
    double r,area;
    printf("Enter any radius : ");
    scanf("%lf",&r);
    area=display(r);
    printf("Area of Circle is %.2lf\n",area);
    getch();

}
