#include<stdio.h>
int main()
{
    int row,col,n,count=0;
    printf("How many number : ");
    scanf("%d",&n);
    for(row=n; row>=1; row--)
    {
        for(col=row; col>=1; col--)
        {
            count++;
            if(count%2==0)
            printf("1 ");
            else
            printf("0 ");
        }
        printf("\n");
    }
}
