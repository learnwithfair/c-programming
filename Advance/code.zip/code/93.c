#include<stdio.h>
int main()
{
    int i,len,count=0;
    char str[20],ch;
    char *p;
    printf("Enter string : ");
    gets(str);
    strlwr(str);
    for(ch='a'; ch<='z'; ch++)
    {
        i=0;
        p=&str[0];
        while(str[i]!=NULL)
        {
            if(ch==*p)
            {
                count++;
            }
            i++;
            p++;

        }
        if(count!=0)
            printf("%c = %d\n",ch,count);
        count=0;
    }
    getch();

}
