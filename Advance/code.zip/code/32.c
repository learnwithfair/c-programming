#include<stdio.h>
int main()
{
    int n,rev,i,r;
    printf("Enter any numbers : ");
    scanf("%d",&n);
    printf("The reverse value is ");
    while(n!=0)
    {
        rev=n%10;
        printf("%d",rev);
        r=n/10;
        n=r;
    }
    getch();
}
