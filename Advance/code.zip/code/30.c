#include<stdio.h>
int main()
{
    int n,r,row,ncr;
    printf("Enter number of rows : ");
    scanf("%d",&row);
    for(n=0; n<row; n++)
    {
        for(r=0; r<=n; r++)
        {
            if(n==0 || r==0)
            {
                ncr=1;
                printf("%d ",ncr);
            }
            else
            {
                ncr=ncr*(n-r+1)/r;
                printf("%d ",ncr);

            }

        }

        printf("\n");

    }
    getch();
}
