#include<stdio.h>
int main()
{
    int num,rem,binary=0,i=1;
    printf("Enter any Decimal number : ");
    scanf("%d",&num);
    while(num!=0){
        rem=num%2;
        num=num/2;
        binary=binary+(i*rem);
        i=i*10;
    }
    printf("Equivalent Binary number is : %d\n",binary);
    getch();
}
