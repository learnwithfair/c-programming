#include<stdio.h>
int display(int a)
{
    int i,fact=1;
    for(i=1;i<=a;i++)
    {
        fact=fact*i;
    }
    return fact;
}
int main()
{
    int i,n,fact;
    printf("Enter any number : ");
    scanf("%d",&n);
    fact=display(n);
    printf("The %d number of Factorial value is %d",n,fact);
    getch();
}
