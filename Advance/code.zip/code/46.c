#include<stdio.h>
int main()
{
    int arra[200],i,n;
    printf("How many number : ");
    scanf("%d",&n);
    printf("Enter array numbers : ");
    for(i=0; i<n; i++)
    {
        scanf("%d",&arra[i]);

    }
    printf("Array series is : ");
    for(i=0; i<n; i++)
    {
        printf("%d ",arra[i]);
    }
    getch();

}
