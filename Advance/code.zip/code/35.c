#include<stdio.h>
int main()
{
    int n;
    printf("Enter decimal number : ");
    scanf("%d",&n);
    printf("Hexadecimal number is %X\n",n);
    getch();
}
