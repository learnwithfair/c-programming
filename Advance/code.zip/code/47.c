#include<stdio.h>
int main()
{
    int i,n,arra[200],p;
    printf("How many number : ");
    scanf("%d",&n);
    printf("Enter array : ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arra[i]);
    }
    printf("Enter position for delete in array: ");
    scanf("%d",&p);
    printf("Array series is : ");
    for(i=0;i<n;i++)
    {
        if((i+1)==p)
        {
            continue;
        }
        printf("%d ",arra[i]);
    }
    getch();
}
