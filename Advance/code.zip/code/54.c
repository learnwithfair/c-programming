#include<stdio.h>
int main()
{
    char arra[200],arra1[20];
    int i,len=0,j=0;
    printf("Enter 1st String : ");
    gets(arra);
    printf("Enter 2nd String : ");
    gets(arra1);
    strcat(arra,arra1);
    printf("%s",arra);
    getch();

}
