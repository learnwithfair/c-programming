#include<stdio.h>
int main()
{
    char ch;
    FILE *file;
    file=fopen("number 67.text","r");
    while(!feof(file))
    {
        ch=fgetc(file);
        printf("%c",ch);
    }


    fclose(file);

    getch();

}
