#include<stdio.h>
int display(int a,int b)
{
    int i,mul=1,fact=1;
    for(i=1;i<=b;i++)
    {
        mul=mul*a;
        a--;
    }
    for(i=1;i<=b;i++)
    {
        fact=fact*i;
    }
    return mul/fact;
}
int main()
{
    int n,r,ncr;
    printf("Enter value n & r : ");
    scanf("%d %d",&n,&r);
    ncr=display(n,r);
    printf("%dC%d = %d",n,r,ncr);
    getch();
}
