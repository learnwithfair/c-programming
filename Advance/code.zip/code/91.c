#include<stdio.h>
#include<string.h>
int main()
{
    char *st;
    int len,i;
    st=(char*)malloc(sizeof(char)*100);
    printf("Enter any string : ");
    gets(st);

    len=strlen(st);
    for(i=len-1;i>=0;i--)
    {
        printf("%c ",st[i]);
    }
}
