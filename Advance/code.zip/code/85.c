#include<stdio.h>
int main()
{
    int num1,num2,R;
    scanf("%d %d",&num1,&num2);
    int *p1,*p2;
    p1=&num1;
    p2=&num2;
    printf("%d",*p1 * *p2);
}
