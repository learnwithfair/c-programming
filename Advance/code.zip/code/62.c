#include<stdio.h>
int main()
{
    char ch;
    FILE *R;
    R=fopen("62.text","r");

    while(!feof(R))
    {

        ch=fgetc(R);
        if(ch>='A'&&ch<='Z')
        {
            printf("%c",ch+32);
        }
        else
            printf("%c",ch);

    }
    fclose(R);
}
