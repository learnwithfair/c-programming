#include<stdio.h>
int main()
{
    double pi=3.1416,result;
    int n;
    scanf("%d",&n);
    result= asin(n)*180/pi;
    printf("%.2lf",result);
}
