#include<stdio.h>
int main()
{
    float num1,num2,R;
    scanf("%f %f",&num1,&num2);
    float *p1,*p2;
    p1=&num1;
    p2=&num2;
    if(*p1>*p2)
    printf("%.3f",*p1);
    else
    printf("%.3f",*p2);
}

