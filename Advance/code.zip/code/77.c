#include<stdio.h>
int display(int num1,int num2)
{
    int tem;
    while(num2!=0)
    {
        tem=num1%num2;
        num1=num2;
        num2=tem;
    }
    return num1;
}
int main()
{
    int num1,num2,GCD;
    printf("Enter First number : ");
    scanf("%d",&num1);
    printf("Enter Second number : ");
    scanf("%d",&num2);
    GCD=display(num1,num2);
    printf("The value of GCD is %d\n",GCD);
    getch();
}
