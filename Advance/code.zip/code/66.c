#include<stdio.h>
int main()
{
    int arra[20],i,count,j,n,tem;
    FILE *file;
    file=fopen("DIS.text","w");
    printf("How many number : ");
    scanf("%d",&n);
    printf("Enter numbers : ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arra[i]);
        fprintf(file,"%d ",arra[i]);
    }


    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(arra[i]<arra[j])
            {
                tem=arra[i];
                arra[i]=arra[j];
                arra[j]=tem;
            }
        }
    }
    fputs("\n",file);
    for(i=0;i<n;i++)
        fprintf(file,"%d ",arra[i]);
        fclose(file);

}
