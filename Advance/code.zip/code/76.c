#include<stdio.h>
int display(int n)
{
    int s1=0,tem1,r1;
    while(n>9)
    {
        while(n!=0)
        {
            tem1=n%10;
            s1=s1+tem1;
            r1=n/10;
            n=r1;
        }
        n=s1;
        s1=0;
    }
    return n;
}
int main()
{
    int n,result;
    printf("Enter any number : ");
    scanf("%d",&n);
    result=display(n);

    printf("The Digital root of value is %d\n",result);

    getch();
}
