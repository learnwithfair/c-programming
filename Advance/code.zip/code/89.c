#include<stdio.h>
int main()
{
    char str1[20],str2[20];
    int len1,len2,*p1,*p2;
    printf("Enter 1st String : ");
    gets(str1);
    printf("Enter 2nd String : ");
    gets(str2);
    len1=strlen(str1);
    len2=strlen(str2);
    p1=&len1;
    p2=&len2;
    if(*p1>*p2)
        printf("Maximum string is %s",str1);
    else
        printf("Maximum string is %s",str2);
}
