#include<stdio.h>
int main()
{
    int arra[20],n,i,j,tem;
    printf("How many number : ");
    scanf("%d",&n);
    printf("Enter element : ");
    for(i=0; i<n; i++)
        scanf("%d",&arra[i]);

    for(i=0; i<n-1; i++)
    {
        for(j=1+i; j<n; j++)
        {
            if(arra[i]<arra[j])
            {
                tem=arra[i];
                arra[i]=arra[j];
                arra[j]=tem;
            }
        }
    }
    for(i=0; i<n; i++)
        printf("%d ",arra[i]);
    getch();
}
