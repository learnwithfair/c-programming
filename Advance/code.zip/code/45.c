#include<stdio.h>
int main()
{
    int n,i,max,arra[20];
    printf("How many term : ");
    scanf("%d",&n);
    printf("Enter array values : ");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arra[i]);
    }
    max=arra[0];
    for(i=1;i<n;i++)
    {
        if(max<arra[i])
            max=arra[i];
    }
    printf("Maximum value is %d\n",max);
    getch();
}
