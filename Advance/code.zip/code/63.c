#include<stdio.h>
int main()
{
    char str[200],ch;
    int small=0,capital=0,other=0,i=0,word=0,digit=0,line=0;
    printf("Enter any String : ");
    gets(str);
    while((ch=str[i])!='\0')
    {
        if (ch>='a'&&ch<='z')
        {
            small++;
        }
        else if(ch>='A'&&ch<='Z')
        {
            capital++;
        }
        else if(ch>='0'&&ch<='9')
        {
            digit++;
        }
        else if(ch==' ')
        {
            word++;
        }
        else if(ch=='.')
        {
            line++;
        }
        else
        {
            other++;
        }
        i++;


    }
    word++;
    printf("the small numbers %d\n",small);
    printf("the capital numbers %d\n",capital);
    printf("the Digit numbers %d\n",digit);
    printf("the Word numbers %d\n",word);
    printf("the Line numbers %d\n",line);
    printf("the others numbers %d\n",other);
    getch();
}

