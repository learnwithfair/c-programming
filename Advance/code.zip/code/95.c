#include<stdio.h>
int main()
{
    int num1,num2,rem;
    printf("Enter two numbers : ");
    scanf("%d %d",&num1,&num2);
    int *p1,*p2;
    p1=&num1;
    p2=&num2;
    rem=*p1;
    *p1=*p2;
    *p2=rem;
    printf("First Number = %d\n",*p1);
    printf("Second Number = %d\n",*p2);
}
