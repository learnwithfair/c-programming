#include<stdio.h>
int main()
{
    int num1,num2,tem;
    printf("Enter First number : ");
    scanf("%d",&num1);
    printf("Enter Second number : ");
    scanf("%d",&num2);
    while(num2!=0)
    {
        tem=num1%num2;
        num1=num2;
        num2=tem;
    }
    printf("The GCD value is %d\n",num1);
    getch();
}
