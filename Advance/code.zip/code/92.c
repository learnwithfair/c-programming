#include<stdio.h>
#include<string.h>
int main()
{
    char str[20];
    int i=0,len,vowel=0,consonant=0,digit=0,space=0,other=0;
    printf("Enter string : ");
    gets(str);
    char *p;
    p=&str[0];
    while(str[i]!='\0')
    {
        if(*p=='A'||*p=='E'||*p=='I'||*p=='O'||*p=='U'||
           *p=='a'||*p=='e'||*p=='i'||*p=='o'||*p=='u')
            vowel++;
        else if(*p>='A'&&*p<='Z'||*p>='a'&&*p<='z')
            consonant++;
        else if(*p>='1'&&*p<='9')
            digit++;
        else if(*p==' ')
            space++;
        else
            other++;
            i++;
            p++;
    }
    space++;
    printf("Vowel number is : %d\n",vowel);
    printf("Consonant number is : %d\n",consonant);
    printf("Digit number is : %d\n",digit);
    printf("Space number is : %d\n",space);
    printf("Other number is : %d\n",other);
    getch();
}
