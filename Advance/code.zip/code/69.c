#include<stdio.h>
struct person
{
    char name[20];
    int mark1,mark2,mark3;
};
int main()
{
    struct person person[20];
    int i,n;
    double avg,GPA;
    printf("How many students : ");
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        printf("Enter student name : ");
        scanf("%s",person[i].name);
        printf("Enter First Subject Mark : ");
        scanf("%d",&person[i].mark1);
        printf("Enter Second Subject Mark : ");
        scanf("%d",&person[i].mark2);
        printf("Enter Third Subject Mark : ");
        scanf("%d",&person[i].mark3);
    }

    //
    for(i=0; i<n; i++)
    {
        avg=person[i].mark1+person[i].mark2+person[i].mark3;
        if(avg>=240&&avg<=300)
            GPA=5.0;
        else if(avg>=210&&avg<240)
            GPA=4.0;
        else if(avg>=180&&avg<210)
            GPA=3.5;
        else if(avg>=150&&avg<180)
            GPA=3.0;
        else if(avg>=120&&avg<150)
            GPA=2.0;
        else if(avg>=99&&avg<120)
            GPA=1.0;
        else
            GPA=0.0;



        printf("\n\n%d number student name : %s\n",i+1,person[i].name);
        printf("First Subject Mark : %d\n",person[i].mark1);

        printf("Second Subject Mark : %d\n",person[i].mark2);

        printf("Third Subject Mark : %d\n",person[i].mark3);
        printf("Average Mark : %.2lf\n",avg/3.0);
        printf("GPA : %.lf\n",GPA);
    }
}
