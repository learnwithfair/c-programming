#include<stdio.h>
int display(int n, int r)
{
    int i,result=1;
    for(i=1;i<=r;i++)
    {
        result=result*n;
        n--;
    }
    return result;
}
int main()
{
    int n,r,result;
    printf("Enter n Value : ");
    scanf("%d",&n);
    printf("Enter r Value : ");
    scanf("%d",&r);
    result=display(n,r);
    printf("nPr Value is %d\n",result);
    getch();
}

