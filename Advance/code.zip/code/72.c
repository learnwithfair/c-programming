#include<stdio.h>
struct person
{
    char team[20],name1[20],name2[20];
    int run1,run2;
};
int main()
{
    struct person person[20];
    int i,n;
    double avg;
    printf("How many team : ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("Team name : ");
        scanf("%s",person[i].team);
        printf("1st player name : ");
        scanf("%s",person[i].name1);
        printf("Enter 1st player Run : ");
        scanf("%d",&person[i].run1);
        printf("2nd player name : ");
        scanf("%s",person[i].name2);
        printf("Enter 2nd player Run : ");
        scanf("%d",&person[i].run2);

    }

    //
    printf("Team Information : \n\n");
     for(i=0;i<n;i++)
    {
        avg=(person[i].run1+person[i].run2)/2.0;
        printf("\n\n%d number Team Information : \n",i+1);
        printf("Team name : %s\n",person[i].team);
        printf("1st player name : %s\n",person[i].name1);
        printf("1st player Run : %d \n",person[i].run1);
        printf("2nd player name : %s\n",person[i].name2);
        printf("2nd player Run : %d\n",person[i].run2);
        printf("Average Run : %.2lf\n",avg);


    }
    getch();
}
