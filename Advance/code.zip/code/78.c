#include<stdio.h>
int display(int a, int b)
{
    int GCD,num1,num2,tem;
    num1=a;
    num2=b;
    while(num2!=0)
    {
        tem=num1%num2;
        num1=num2;
        num2=tem;
    }
    GCD=num1;
    return (a*b)/GCD;
}
int main()
{
    int num1,num2,LCM;
    printf("Enter two number : ");
    scanf("%d %d",&num1,&num2);
    LCM=display(num1,num2);
    printf("LCM value is %d\n",LCM);
    getch();
}
