#include<stdio.h>
int main()
{
    int j,len,count=0;
    char str[20],i;
    FILE *file;
    file=fopen("FFF.text","w");
    if(file==NULL)
    {
        printf("File does not exit \n");
    }
    else
    {

        printf("Enter any string : ");
        gets(str);
        len=strlen(str);

        for(i='a'; i<='z'; i++)
        {
            for(j=0; j<len; j++)
            {
                if(i==str[j])
                    count++;
            }
            if(count!=0)
            {
                fprintf(file,"%c = %d\n",i,count);
                count=0;
            }


        }
        fclose(file);
    }
}
