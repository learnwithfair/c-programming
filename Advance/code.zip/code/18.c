#include<stdio.h>
int main()
{
    int a,b,c,max;
    printf("Enter a number : ");
    scanf("%d",&a);
    printf("Enter b number : ");
    scanf("%d",&b);
    printf("Enter c number : ");
    scanf("%d",&c);

    if(a>b&&a>c)
        max=a;
    else if(b>a&&b>c)
        max=b;
    else
        max=c;
    printf("Maximum value is %d",max);
}
