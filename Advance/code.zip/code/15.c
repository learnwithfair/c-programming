#include<stdio.h>
int main()
{
    int a,b,c;
    double x1,x2,d;
    printf("Enter a,b,c : ");
    scanf("%d %d %d",&a,&b,&c);
    d=b*b-4*a*c;
    if(d>=0)
    {
        x1=(-b+sqrt(d))/(2*a);
        x2=(-b-sqrt(d))/(2*a);
        printf("X1 = %.2lf , %.2lf\n",x1,x2);
    }
    else
        printf("The number is Imaginary");
    getch();
}
