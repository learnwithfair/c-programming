#include<stdio.h>
int main()
{
    double x,n;
    scanf("%lf",&x);
    n=log10(x);
    printf("log10(%.0lf)= %.2lf",x,n);
    return 0;
}
